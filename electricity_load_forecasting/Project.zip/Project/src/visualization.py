"""Visualization Utilities using Plotly Interactive Charts
Generates high-fidelity charts for forecasting, exploration, SOM patterns, and model evaluation.
"""

from typing import Dict, List, Optional
import numpy as np
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from src.config import (
    BASELINE_RESULTS,
    GA_CANDIDATES,
    GA_OPTIMIZED_RESULTS,
    SOM_GRID_X,
    SOM_GRID_Y,
)


def plot_actual_vs_predicted(
    forecast_df: pd.DataFrame,
    customer_id: str,
    target_date: str,
    model_name: str = "Baseline PSF-SOM-ANN",
    metrics: Optional[Dict[str, float]] = None
) -> go.Figure:
    """Generate interactive 96-point curve of Actual vs. Predicted load with error shading."""
    fig = go.Figure()

    # If actual load is available
    if "Actual_Load" in forecast_df.columns:
        fig.add_trace(go.Scatter(
            x=forecast_df["Time"],
            y=forecast_df["Actual_Load"],
            mode="lines+markers",
            name="Actual Load",
            line=dict(color="#2563eb", width=2.5),
            marker=dict(size=4)
        ))

    # Predicted load
    fig.add_trace(go.Scatter(
        x=forecast_df["Time"],
        y=forecast_df["Predicted_Load"],
        mode="lines+markers",
        name=f"Predicted Load ({model_name})",
        line=dict(color="#f97316", width=2.5, dash="dash"),
        marker=dict(size=4)
    ))

    subtitle = ""
    if metrics:
        subtitle = (
            f"<br><sup>MAE: {metrics.get('mae', 0):.2f} | "
            f"RMSE: {metrics.get('rmse', 0):.2f} | "
            f"MAPE: {metrics.get('mape', 0):.2f}%</sup>"
        )

    fig.update_layout(
        title=f"<b>96-Point Day-Ahead Load Forecast</b>: Customer {customer_id} on {target_date}{subtitle}",
        xaxis_title="Time of Day (15-Minute Intervals)",
        yaxis_title="Electricity Consumption (kWh)",
        hovermode="x unified",
        template="plotly_white",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1),
        margin=dict(l=40, r=40, t=80, b=40)
    )
    return fig


def plot_som_grid_activity(
    node_counts: Dict[int, int],
    selected_pattern_id: Optional[int] = None
) -> go.Figure:
    """Generate 10x10 SOM grid heatmap indicating active pattern nodes and profile density."""
    grid_matrix = np.zeros((SOM_GRID_X, SOM_GRID_Y))
    text_matrix = [["" for _ in range(SOM_GRID_Y)] for _ in range(SOM_GRID_X)]

    for pattern_id, count in node_counts.items():
        row = pattern_id // SOM_GRID_Y
        col = pattern_id % SOM_GRID_Y
        if 0 <= row < SOM_GRID_X and 0 <= col < SOM_GRID_Y:
            grid_matrix[row][col] = count
            text_matrix[row][col] = f"ID: {pattern_id}<br>{count} profiles"

    fig = go.Figure(data=go.Heatmap(
        z=grid_matrix,
        text=text_matrix,
        texttemplate="%{text}",
        hoverinfo="text",
        colorscale="Blues",
        showscale=True,
        colorbar=dict(title="Profiles")
    ))

    # Highlight selected node if provided
    if selected_pattern_id is not None:
        sel_row = selected_pattern_id // SOM_GRID_Y
        sel_col = selected_pattern_id % SOM_GRID_Y
        fig.add_shape(
            type="rect",
            x0=sel_col - 0.48, y0=sel_row - 0.48,
            x1=sel_col + 0.48, y1=sel_row + 0.48,
            line=dict(color="#ef4444", width=3)
        )

    fig.update_layout(
        title="<b>10×10 SOM Pattern Grid Activity</b> (53 Active Pattern Nodes)",
        xaxis=dict(title="SOM Column", tickmode="linear", dtick=1),
        yaxis=dict(title="SOM Row", tickmode="linear", dtick=1, autorange="reversed"),
        template="plotly_white",
        margin=dict(l=40, r=40, t=60, b=40)
    )
    return fig


def plot_model_comparison_metrics() -> go.Figure:
    """Generate comparative bar charts comparing Baseline vs. GA-Optimized models."""
    metrics = ["MAE", "RMSE", "MAPE (%)"]
    baseline_vals = [BASELINE_RESULTS["mae"], BASELINE_RESULTS["rmse"], BASELINE_RESULTS["mape"]]
    ga_vals = [GA_OPTIMIZED_RESULTS["mae"], GA_OPTIMIZED_RESULTS["rmse"], GA_OPTIMIZED_RESULTS["mape"]]

    fig = go.Figure()
    fig.add_trace(go.Bar(
        name="Baseline (PSF-SOM-ANN)",
        x=metrics,
        y=baseline_vals,
        marker_color="#3b82f6",
        text=[f"{v:.2f}" for v in baseline_vals],
        textposition="auto"
    ))
    fig.add_trace(go.Bar(
        name="GA-Optimized (PSF-SOM-ANN)",
        x=metrics,
        y=ga_vals,
        marker_color="#f59e0b",
        text=[f"{v:.2f}" for v in ga_vals],
        textposition="auto"
    ))

    fig.update_layout(
        title="<b>Experimental Model Comparison: Baseline vs. GA-Optimized</b>",
        barmode="group",
        yaxis_title="Metric Value",
        template="plotly_white",
        legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1)
    )
    return fig


def plot_execution_times() -> go.Figure:
    """Compare training and prediction times between models."""
    categories = ["Training Time (s)", "Prediction Time (s)"]
    baseline_times = [BASELINE_RESULTS["training_time"], BASELINE_RESULTS["prediction_time"]]
    ga_times = [GA_OPTIMIZED_RESULTS["training_time"], GA_OPTIMIZED_RESULTS["prediction_time"]]

    fig = go.Figure()
    fig.add_trace(go.Bar(
        name="Baseline",
        x=categories,
        y=baseline_times,
        marker_color="#6366f1",
        text=[f"{v:.2f}s" for v in baseline_times],
        textposition="auto"
    ))
    fig.add_trace(go.Bar(
        name="GA-Optimized",
        x=categories,
        y=ga_times,
        marker_color="#ec4899",
        text=[f"{v:.2f}s" for v in ga_times],
        textposition="auto"
    ))

    fig.update_layout(
        title="<b>Computational Efficiency Comparison</b>",
        barmode="group",
        yaxis_title="Time (Seconds)",
        template="plotly_white"
    )
    return fig


def plot_ga_candidate_fitness() -> go.Figure:
    """Plot GA candidate chromosomes and their validation RMSE fitness."""
    df = pd.DataFrame(GA_CANDIDATES)
    fig = go.Figure()

    colors = ["#10b981" if c else "#94a3b8" for c in df["selected"]]

    fig.add_trace(go.Bar(
        x=[f"Cand {i} (N={n}, lr={lr:.4f})" for i, n, lr in zip(df["candidate"], df["hidden_neurons"], df["learning_rate"])],
        y=df["val_rmse"],
        marker_color=colors,
        text=[f"RMSE: {v:.2f}" + (" (Selected)" if s else "") for v, s in zip(df["val_rmse"], df["selected"])],
        textposition="outside"
    ))

    max_val = max(df["val_rmse"]) if not df.empty else 1.0
    fig.update_layout(
        title="<b>Lightweight GA Optimization: Candidate Fitness (Validation RMSE)</b>",
        xaxis_title="Candidate Chromosome (Hidden Neurons, Learning Rate)",
        yaxis_title="Validation RMSE (Lower is Better)",
        yaxis_range=[0, max_val * 1.3],
        template="plotly_white"
    )
    return fig
