"""End-to-End Forecasting Engine
Connects PSF sequences, SOM cluster prototypes, ANN predictions, and inverse scaling to produce 96-point load curves.
"""

import time
from typing import Dict, List, Optional, Tuple, Union
import numpy as np
import pandas as pd

from src.config import ACTIVE_PATTERN_CLASSES, MAPE_EPSILON, PSF_WINDOW_SIZE
from src.daily_profiles import TIME_SLOT_COLUMNS
from src.evaluation import evaluate_forecast
from src.preprocessing import DataPreprocessor
from src.psf_model import create_single_inference_input, one_hot_encode_pattern
from src.som_model import SOMClusterer
from src.ann_model import PatternPredictorANN


class LoadForecaster:
    """Orchestrates end-to-end inference from raw history to 96-reading forecast."""

    def __init__(
        self,
        som_clusterer: SOMClusterer,
        preprocessor: DataPreprocessor,
        baseline_ann=None,
        ga_ann=None
    ):
        self.som = som_clusterer
        self.preprocessor = preprocessor
        self.baseline_ann = baseline_ann
        self.ga_ann = ga_ann

        # Auto-load saved models if available and not explicitly provided
        if self.baseline_ann is None:
            cand = PatternPredictorANN(model_type="baseline")
            if cand.load():
                self.baseline_ann = cand

        if self.ga_ann is None:
            cand_ga = PatternPredictorANN(model_type="ga_optimized")
            if cand_ga.load():
                self.ga_ann = cand_ga

    def forecast_single_day(
        self,
        customer_id: str,
        target_date: Union[str, pd.Timestamp],
        daily_profiles_df: pd.DataFrame,
        model_type: str = "baseline"
    ) -> Dict:
        """Generate 96-point day-ahead forecast for a customer on a given target date."""
        target_dt = pd.to_datetime(target_date).date()
        cust_profiles = daily_profiles_df[daily_profiles_df["Customer"] == customer_id].copy()
        cust_profiles["Date"] = pd.to_datetime(cust_profiles["Date"]).dt.date
        cust_profiles = cust_profiles.sort_values("Date").reset_index(drop=True)

        target_row = cust_profiles[cust_profiles["Date"] == target_dt]
        has_actual = not target_row.empty

        # Locate historical 3 previous days
        history_rows = cust_profiles[cust_profiles["Date"] < target_dt].tail(PSF_WINDOW_SIZE)
        if len(history_rows) < PSF_WINDOW_SIZE:
            raise ValueError(
                f"Insufficient historical data: customer {customer_id} requires {PSF_WINDOW_SIZE} "
                f"previous daily profiles before {target_dt}, found {len(history_rows)}."
            )

        # Map previous days to SOM pattern IDs
        hist_raw = history_rows[TIME_SLOT_COLUMNS].values.astype(float)
        if self.preprocessor.is_fitted:
            hist_scaled = self.preprocessor.scaler.transform(hist_raw)
        else:
            hist_scaled = hist_raw

        hist_patterns = [self.som.get_pattern_id(profile) for profile in hist_scaled]

        # Extract calendar features of target day
        dow = target_dt.weekday()
        month = target_dt.month

        # Select ANN model
        ann = self.ga_ann if model_type == "ga_optimized" else self.baseline_ann

        # Dynamically determine feature dimensions expected by the model architecture
        if ann is not None and getattr(ann, "model", None) is not None and hasattr(ann.model, "input_shape") and ann.model.input_shape:
            expected_input_dim = ann.model.input_shape[-1]
            num_classes = (expected_input_dim - 2) // PSF_WINDOW_SIZE
        else:
            num_classes = ACTIVE_PATTERN_CLASSES

        # Form feature vector matching model's expected dimension
        X_input = create_single_inference_input(
            hist_patterns=hist_patterns,
            target_day_of_week=dow,
            target_month=month,
            pattern_to_class_idx=self.som.pattern_to_class_idx,
            num_classes=num_classes
        )

        if ann is not None and getattr(ann, "model", None) is not None:
            pred_class_idx = ann.predict_pattern_class(X_input)
            predicted_pattern_id = self.som.class_idx_to_pattern.get(pred_class_idx, hist_patterns[-1])
        else:
            # Fallback heuristic: recurring pattern or most frequent recent pattern
            predicted_pattern_id = hist_patterns[-1]

        # Retrieve SOM prototype load curve
        pred_scaled_profile = self.som.get_prototype_curve(predicted_pattern_id)

        # Inverse transform to original load units
        if self.preprocessor.is_fitted:
            pred_profile = self.preprocessor.inverse_transform(pred_scaled_profile).flatten()
        else:
            pred_profile = pred_scaled_profile

        # Assemble results
        results_df = pd.DataFrame({
            "Time": TIME_SLOT_COLUMNS,
            "Predicted_Load": np.round(pred_profile, 2)
        })

        metrics = {}
        if has_actual:
            actual_profile = target_row.iloc[0][TIME_SLOT_COLUMNS].values.astype(float)
            results_df["Actual_Load"] = np.round(actual_profile, 2)
            results_df["Absolute_Error"] = np.round(np.abs(results_df["Actual_Load"] - results_df["Predicted_Load"]), 2)
            metrics = evaluate_forecast(actual_profile, pred_profile)

        return {
            "customer": customer_id,
            "date": str(target_dt),
            "model_type": model_type,
            "history_patterns": hist_patterns,
            "predicted_pattern_id": predicted_pattern_id,
            "forecast_df": results_df,
            "metrics": metrics,
            "has_ground_truth": has_actual
        }

    def evaluate_test_set(
        self,
        test_df: pd.DataFrame,
        daily_profiles_df: pd.DataFrame,
        model_type: str = "baseline"
    ) -> Dict:
        """Evaluate entire test set chronologically and return MAE, RMSE, MAPE, count, and runtime."""
        t0 = time.time()
        ann = self.ga_ann if model_type == "ga_optimized" else self.baseline_ann

        # Pre-scale all profiles in daily_profiles_df once for computational efficiency
        all_raw = daily_profiles_df[TIME_SLOT_COLUMNS].values.astype(float)
        if self.preprocessor.is_fitted:
            all_scaled = self.preprocessor.scaler.transform(all_raw)
        else:
            all_scaled = all_raw

        all_patterns = self.som.map_profiles_to_patterns(all_scaled)

        # Build fast lookup map: (Customer, Date) -> (pattern_id, raw_profile)
        lookup_map = {}
        for idx, row in daily_profiles_df.iterrows():
            cust = row["Customer"]
            dt = pd.to_datetime(row["Date"]).date()
            raw_prof = all_raw[idx]
            lookup_map[(cust, dt)] = (all_patterns[idx], raw_prof)

        # Determine expected classes from ANN model shape
        if ann is not None and getattr(ann, "model", None) is not None and hasattr(ann.model, "input_shape") and ann.model.input_shape:
            num_classes = (ann.model.input_shape[-1] - 2) // PSF_WINDOW_SIZE
        else:
            num_classes = ACTIVE_PATTERN_CLASSES

        X_batch = []
        actuals = []
        valid_indices = []

        test_rows = test_df.reset_index(drop=True)
        for idx, row in test_rows.iterrows():
            cust = row["Customer"]
            target_dt = pd.to_datetime(row["Date"]).date()

            # Find 3 previous historical days for this customer
            hist_dts = [target_dt - pd.Timedelta(days=d) for d in range(PSF_WINDOW_SIZE, 0, -1)]
            hist_pids = [lookup_map[(cust, h_dt)][0] for h_dt in hist_dts if (cust, h_dt) in lookup_map]

            if len(hist_pids) < PSF_WINDOW_SIZE:
                continue

            dow = target_dt.weekday()
            month = target_dt.month

            # Encode PSF vector
            feature_vector = []
            for pid in hist_pids:
                feature_vector.extend(one_hot_encode_pattern(pid, self.som.pattern_to_class_idx, num_classes=num_classes))
            feature_vector.extend([dow / 6.0, (month - 1) / 11.0])

            X_batch.append(feature_vector)
            actuals.append(row[TIME_SLOT_COLUMNS].values.astype(float))
            valid_indices.append(idx)

        if not X_batch:
            return {"mae": 0.0, "rmse": 0.0, "mape": 0.0, "forecast_count": 0, "runtime_seconds": round(time.time() - t0, 2)}

        X_batch = np.array(X_batch)
        actuals = np.array(actuals)

        if ann is not None and getattr(ann, "model", None) is not None:
            preds_class = ann.predict_pattern_class(X_batch)
            if isinstance(preds_class, (int, np.integer)):
                preds_class = np.array([preds_class])
        else:
            # Heuristic fallback: use last historical pattern ID
            preds_class = np.array([self.som.pattern_to_class_idx.get(X_batch[i, -3], 0) for i in range(len(X_batch))])

        pred_profiles = []
        for c_idx in preds_class:
            pid = self.som.class_idx_to_pattern.get(int(c_idx), int(c_idx))
            scaled_proto = self.som.get_prototype_curve(pid)
            if self.preprocessor.is_fitted:
                unscaled_proto = self.preprocessor.inverse_transform(scaled_proto).flatten()
            else:
                unscaled_proto = scaled_proto.flatten()
            pred_profiles.append(unscaled_proto)

        pred_profiles = np.array(pred_profiles)

        errors = actuals - pred_profiles
        mae = float(np.mean(np.abs(errors)))
        rmse = float(np.sqrt(np.mean(errors ** 2)))

        # Mask/epsilon zero protection for MAPE
        denom = np.maximum(np.abs(actuals), MAPE_EPSILON)
        mape = float(np.mean(np.abs(errors) / denom) * 100.0)

        dt = round(time.time() - t0, 2)
        return {
            "mae": round(mae, 4),
            "rmse": round(rmse, 4),
            "mape": round(mape, 2),
            "forecast_count": len(valid_indices),
            "runtime_seconds": dt
        }


def evaluate_test_set(
    test_df: pd.DataFrame,
    model_type: str = "baseline",
    daily_profiles_df: Optional[pd.DataFrame] = None,
    som_clusterer: Optional[SOMClusterer] = None,
    preprocessor: Optional[DataPreprocessor] = None
) -> Dict:
    """Standalone helper function to evaluate test set."""
    if som_clusterer is None:
        som_clusterer = SOMClusterer()
        som_clusterer.load()
    if preprocessor is None:
        preprocessor = DataPreprocessor()
        preprocessor.load()
    if daily_profiles_df is None:
        from src.fluvius_loader import load_fluvius_data
        df_all, _ = load_fluvius_data()
        from src.daily_profiles import transform_to_daily_profiles
        daily_profiles_df = transform_to_daily_profiles(df_all, "Timestamp", [c for c in df_all.columns if c != "Timestamp"])

    forecaster = LoadForecaster(som_clusterer=som_clusterer, preprocessor=preprocessor)
    return forecaster.evaluate_test_set(test_df=test_df, daily_profiles_df=daily_profiles_df, model_type=model_type)
