"""Electricity Load Forecasting System
Pattern Sequence-Based Forecasting (PSF) + Self-Organizing Maps (SOM) +
Artificial Neural Networks (ANN) + Genetic Algorithm (GA) Optimization
"""

__version__ = "1.0.0"
__author__ = "Final-Year B.Tech CSE (Data Science & Big Data Analytics)"
