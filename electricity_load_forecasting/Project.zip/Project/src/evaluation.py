"""Evaluation Metrics for Electricity Load Forecasting
Includes MAE, RMSE, and MAPE with consistent epsilon handling.
"""

from typing import Dict, Union
import numpy as np
import pandas as pd
from src.config import MAPE_EPSILON


def calculate_mae(y_true: Union[np.ndarray, pd.Series], y_pred: Union[np.ndarray, pd.Series]) -> float:
    """Calculate Mean Absolute Error (MAE)."""
    y_t = np.asarray(y_true, dtype=float)
    y_p = np.asarray(y_pred, dtype=float)
    return float(np.mean(np.abs(y_t - y_p)))


def calculate_rmse(y_true: Union[np.ndarray, pd.Series], y_pred: Union[np.ndarray, pd.Series]) -> float:
    """Calculate Root Mean Squared Error (RMSE)."""
    y_t = np.asarray(y_true, dtype=float)
    y_p = np.asarray(y_pred, dtype=float)
    return float(np.sqrt(np.mean((y_t - y_p) ** 2)))


def calculate_mape(
    y_true: Union[np.ndarray, pd.Series],
    y_pred: Union[np.ndarray, pd.Series],
    epsilon: float = MAPE_EPSILON
) -> float:
    """Calculate Mean Absolute Percentage Error (MAPE).

    Uses a small denominator threshold (epsilon = 1e-3) to prevent division by zero,
    matching the exact experimental protocol.
    """
    y_t = np.asarray(y_true, dtype=float)
    y_p = np.asarray(y_pred, dtype=float)
    denominator = np.where(np.abs(y_t) < epsilon, epsilon, np.abs(y_t))
    mape = np.mean(np.abs((y_t - y_p) / denominator)) * 100.0
    return float(mape)


def evaluate_forecast(
    y_true: Union[np.ndarray, pd.Series],
    y_pred: Union[np.ndarray, pd.Series]
) -> Dict[str, float]:
    """Calculate all standard metrics for a given forecast profile."""
    return {
        "mae": calculate_mae(y_true, y_pred),
        "rmse": calculate_rmse(y_true, y_pred),
        "mape": calculate_mape(y_true, y_pred)
    }
