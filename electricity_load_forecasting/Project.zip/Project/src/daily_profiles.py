"""Daily Profile Transformation and Chronological Splitting
Transforms 15-minute time series into 96-reading daily load profiles per customer.
"""

from typing import List, Tuple
import numpy as np
import pandas as pd
from src.config import READINGS_PER_DAY, TRAIN_DAYS


def generate_time_slot_columns() -> List[str]:
    """Generate the 96 time-slot column headers (00:00 to 23:45)."""
    columns = []
    for h in range(24):
        for m in (0, 15, 30, 45):
            columns.append(f"{h:02d}:{m:02d}")
    return columns


TIME_SLOT_COLUMNS = generate_time_slot_columns()


def transform_to_daily_profiles(
    df: pd.DataFrame,
    timestamp_col: str,
    customer_cols: List[str]
) -> pd.DataFrame:
    """Reshape multi-customer time series dataframe into daily profile format.
    
    Output Format:
        Customer | Date | DayOfWeek | Month | 00:00 | 00:15 | ... | 23:45
    """
    df = df.copy()
    df[timestamp_col] = pd.to_datetime(df[timestamp_col])
    df = df.sort_values(timestamp_col).reset_index(drop=True)
    
    df["Date"] = df[timestamp_col].dt.date
    df["Time"] = df[timestamp_col].dt.strftime("%H:%M")
    
    profiles = []
    
    for customer in customer_cols:
        cust_df = df[[timestamp_col, "Date", "Time", customer]].copy()
        
        # Use pivot_table with mean aggregation to safely handle any accidental duplicate timestamps
        pivot = cust_df.pivot_table(index="Date", columns="Time", values=customer, aggfunc="mean")
        
        # Ensure all 96 time slots are present
        for col in TIME_SLOT_COLUMNS:
            if col not in pivot.columns:
                pivot[col] = np.nan
        
        # Reorder to strict 96 slots
        pivot = pivot[TIME_SLOT_COLUMNS]
        
        # Linearly interpolate isolated missing 15-minute readings within the day
        pivot = pivot.interpolate(method="linear", axis=1).bfill(axis=1).ffill(axis=1)
        
        # Drop days that are still entirely or severely empty (e.g. all NaNs)
        pivot = pivot.dropna()
        
        if pivot.empty:
            continue
            
        pivot = pivot.reset_index()
        pivot.insert(0, "Customer", customer)
        
        # Add calendar metadata — convert date objects → datetime64 so .dt works
        pivot["Date"] = pd.to_datetime(pivot["Date"].astype(str))
        date_series = pivot["Date"]
        pivot.insert(2, "DayOfWeek", date_series.dt.dayofweek)
        pivot.insert(3, "Month", date_series.dt.month)
        
        profiles.append(pivot)
        
    if not profiles:
        raise ValueError(
            "Could not construct daily profiles. Please verify the timestamp format "
            "and ensure timestamps have 15-minute resolution (96 intervals per day)."
        )
        
    daily_profiles_df = pd.concat(profiles, ignore_index=True)
    daily_profiles_df = daily_profiles_df.sort_values(["Customer", "Date"]).reset_index(drop=True)
    return daily_profiles_df


def split_daily_profiles_chronologically(
    daily_profiles_df: pd.DataFrame,
    train_days_per_customer: int = TRAIN_DAYS
) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Split profiles chronologically per customer:
    First N days -> Training set (approx 70%)
    Remaining days -> Testing set (approx 30%)
    """
    train_list = []
    test_list = []
    
    customers = daily_profiles_df["Customer"].unique()
    for cust in customers:
        cust_data = daily_profiles_df[daily_profiles_df["Customer"] == cust].sort_values("Date")
        n_days = len(cust_data)
        
        # Use explicit train_days_per_customer if supplied and valid (< n_days)
        if 0 < train_days_per_customer < n_days:
            split_idx = train_days_per_customer
        else:
            split_idx = max(1, int(n_days * 0.70))
            
        train_list.append(cust_data.iloc[:split_idx])
        test_list.append(cust_data.iloc[split_idx:])
        
    train_df = pd.concat(train_list, ignore_index=True) if train_list else pd.DataFrame()
    test_df = pd.concat(test_list, ignore_index=True) if test_list else pd.DataFrame()
    
    return train_df, test_df
