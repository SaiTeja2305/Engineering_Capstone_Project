"""Genetic Algorithm (GA) Hyperparameter Optimizer
Lightweight adaptation searching ANN hidden neurons and learning rate using Validation RMSE.
Operates on the Fluvius 2024 Residential Electricity Load Dataset.
"""

import time
from typing import Dict, List, Optional, Tuple
import numpy as np
import pandas as pd

from src.config import GA_CONFIG, RANDOM_STATE
from src.ann_model import build_ann_model


class LightweightGAOptimizer:
    """Lightweight evolutionary search over ANN hidden neurons and learning rate."""

    def __init__(
        self,
        population_size: int = 5,
        random_seed: int = RANDOM_STATE,
        candidate_epochs: int = 15
    ):
        self.population_size = population_size
        self.search_space = GA_CONFIG["search_space"]
        self.random_seed = random_seed
        self.candidate_epochs = candidate_epochs
        self.candidates: List[Dict] = []
        self.selected_candidate: Optional[Dict] = None
        self.is_optimized: bool = False
        self.execution_time: float = 0.0

    def generate_population(self, seed: Optional[int] = None) -> List[Dict]:
        """Generate candidate chromosomes covering the search space.
        
        Search space:
            - hidden_neurons: [5, 40]
            - learning_rate: [0.0001, 0.01]
        """
        rng = np.random.RandomState(seed if seed is not None else self.random_seed)
        h_min, h_max = self.search_space["hidden_neurons"]
        lr_min, lr_max = self.search_space["learning_rate"]

        # Stratified/diverse initial population across the bounds
        neurons_samples = np.linspace(h_min + 3, h_max - 2, self.population_size, dtype=int)
        lr_samples = np.geomspace(lr_min * 1.5, lr_max * 0.85, self.population_size)

        jitter_n = rng.randint(-2, 3, size=self.population_size)
        neurons_samples = np.clip(neurons_samples + jitter_n, h_min, h_max)

        population = []
        for i in range(self.population_size):
            population.append({
                "candidate": i + 1,
                "hidden_neurons": int(neurons_samples[i]),
                "learning_rate": float(round(lr_samples[i], 7)),
                "val_rmse": None,
                "selected": False
            })
        return population

    def evaluate_candidate(
        self,
        candidate: Dict,
        X_train: np.ndarray,
        y_train: np.ndarray,
        X_val: np.ndarray,
        y_val: np.ndarray,
        som_clusterer=None,
        epochs: int = 15
    ) -> float:
        """Train candidate model on X_train and evaluate Validation RMSE on X_val."""
        input_dim = X_train.shape[1]
        output_classes = y_train.shape[1]

        model = build_ann_model(
            input_dim=input_dim,
            hidden_neurons=candidate["hidden_neurons"],
            output_classes=output_classes,
            learning_rate=candidate["learning_rate"]
        )

        model.fit(
            X_train,
            y_train,
            epochs=epochs,
            batch_size=128,
            verbose=0
        )

        probs = model.predict(X_val, batch_size=256, verbose=0)
        pred_classes = np.argmax(probs, axis=1)

        if som_clusterer and getattr(som_clusterer, "som", None) is not None:
            weights = som_clusterer.som.get_weights()
            grid_y = som_clusterer.grid_y

            true_classes = np.argmax(y_val, axis=1)
            pred_curves = np.array([weights[p // grid_y, p % grid_y] for p in pred_classes])
            true_curves = np.array([weights[p // grid_y, p % grid_y] for p in true_classes])

            val_rmse = float(np.sqrt(np.mean((true_curves - pred_curves) ** 2)))
        else:
            val_rmse = float(np.sqrt(np.mean((y_val - probs) ** 2)))

        return val_rmse

    def run_lightweight_search(
        self,
        X: np.ndarray,
        y: np.ndarray,
        som_clusterer=None,
        validation_split: float = 0.2,
        epochs_per_candidate: Optional[int] = None,
        progress_callback=None
    ) -> Tuple[Dict, List[Dict]]:
        """Execute real lightweight GA hyperparameter evaluation across candidate population.
        
        Calculates validation RMSE dynamically during execution.
        """
        t0 = time.time()
        epochs = epochs_per_candidate or self.candidate_epochs

        split_idx = int(len(X) * (1.0 - validation_split))
        if split_idx <= 0 or split_idx >= len(X):
            split_idx = int(len(X) * 0.8)

        X_train, X_val = X[:split_idx], X[split_idx:]
        y_train, y_val = y[:split_idx], y[split_idx:]

        population = self.generate_population()
        evaluated_candidates = []

        for idx, cand in enumerate(population):
            if progress_callback:
                progress_callback(idx + 1, self.population_size, cand)

            val_rmse = self.evaluate_candidate(
                candidate=cand,
                X_train=X_train,
                y_train=y_train,
                X_val=X_val,
                y_val=y_val,
                som_clusterer=som_clusterer,
                epochs=epochs
            )

            cand_result = dict(cand)
            cand_result["val_rmse"] = round(float(val_rmse), 4)
            evaluated_candidates.append(cand_result)

        best_cand = min(evaluated_candidates, key=lambda c: c["val_rmse"])
        for c in evaluated_candidates:
            c["selected"] = (c["candidate"] == best_cand["candidate"])

        self.candidates = evaluated_candidates
        self.selected_candidate = best_cand
        self.is_optimized = True
        self.execution_time = time.time() - t0

        return best_cand, evaluated_candidates

    def optimize(
        self,
        X: np.ndarray,
        y: np.ndarray,
        som=None,
        preprocessor=None,
        candidate_epochs: Optional[int] = None
    ) -> Dict:
        """Helper method matching standard optimize interface."""
        epochs = candidate_epochs or self.candidate_epochs
        best, candidates = self.run_lightweight_search(
            X=X,
            y=y,
            som_clusterer=som,
            epochs_per_candidate=epochs
        )
        return {
            "best": best,
            "candidates": candidates,
            "runtime": self.execution_time
        }

    def get_candidate_table(self) -> pd.DataFrame:
        """Return structured dataframe of evaluated GA candidates."""
        if not self.candidates:
            self.candidates = self.generate_population()
        df = pd.DataFrame(self.candidates)
        cols = ["Candidate", "Hidden Neurons", "Learning Rate", "Validation RMSE", "Selected"]
        df.columns = [c for c in cols if c.lower().replace(" ", "_") in df.columns or c in df.columns]
        return df
