"""Pattern Sequence-Based Forecasting (PSF) Sequence Construction
Constructs sliding-window pattern sequences and feature matrices for ANN training and inference.
"""

from typing import Dict, List, Optional, Tuple
import numpy as np
import pandas as pd
from src.config import (
    ACTIVE_PATTERN_CLASSES,
    ANN_TOTAL_INPUT_FEATURES,
    PSF_WINDOW_SIZE,
)


def one_hot_encode_pattern(
    pattern_id: int,
    pattern_to_class_idx: Dict[int, int],
    num_classes: int = ACTIVE_PATTERN_CLASSES
) -> np.ndarray:
    """Encode single pattern ID into one-hot vector across active classes."""
    vec = np.zeros(num_classes, dtype=np.float32)
    idx = pattern_to_class_idx.get(pattern_id, 0)
    if 0 <= idx < num_classes:
        vec[idx] = 1.0
    return vec


def build_psf_sequences(
    daily_profiles_df: pd.DataFrame,
    pattern_ids: np.ndarray,
    pattern_to_class_idx: Dict[int, int],
    window_size: int = PSF_WINDOW_SIZE,
    num_classes: int = ACTIVE_PATTERN_CLASSES
) -> Tuple[np.ndarray, np.ndarray, List[Dict]]:
    """Build ANN training matrices (X, y) and metadata tracking for each sequence.
    
    X shape: (N_sequences, 161)
        - 3 previous days * 53 one-hot = 159 features
        - DayOfWeek (normalized to [0, 1] via /6.0) = 1 feature
        - Month (normalized to [0, 1] via /12.0) = 1 feature
    y shape: (N_sequences, 53)
        - Next day's pattern ID (one-hot)
    """
    df = daily_profiles_df.copy()
    df["PatternID"] = pattern_ids
    
    X_list = []
    y_list = []
    meta_list = []
    
    customers = df["Customer"].unique()
    for cust in customers:
        cust_df = df[df["Customer"] == cust].sort_values("Date").reset_index(drop=True)
        n_days = len(cust_df)
        if n_days <= window_size:
            continue
            
        for i in range(window_size, n_days):
            # Window of previous pattern IDs: [i - window_size, ..., i - 1]
            hist_patterns = cust_df.loc[i - window_size : i - 1, "PatternID"].values
            
            # One-hot encode history
            hist_one_hots = [
                one_hot_encode_pattern(p, pattern_to_class_idx, num_classes)
                for p in hist_patterns
            ]
            hist_vec = np.concatenate(hist_one_hots)  # 3 * 53 = 159
            
            # Target day calendar attributes
            target_row = cust_df.iloc[i]
            dow_norm = float(target_row["DayOfWeek"]) / 6.0
            month_norm = float(target_row["Month"]) / 12.0
            
            features = np.concatenate([hist_vec, [dow_norm, month_norm]])  # 161 features
            
            # Target pattern
            target_pattern = int(target_row["PatternID"])
            target_vec = one_hot_encode_pattern(target_pattern, pattern_to_class_idx, num_classes)
            
            X_list.append(features)
            y_list.append(target_vec)
            meta_list.append({
                "Customer": cust,
                "Date": target_row["Date"],
                "TargetPattern": target_pattern,
                "HistPatterns": list(hist_patterns)
            })
            
    if not X_list:
        return np.empty((0, ANN_TOTAL_INPUT_FEATURES)), np.empty((0, num_classes)), []
        
    return np.array(X_list, dtype=np.float32), np.array(y_list, dtype=np.float32), meta_list


def create_single_inference_input(
    hist_patterns: List[int],
    target_day_of_week: int,
    target_month: int,
    pattern_to_class_idx: Dict[int, int],
    num_classes: int = ACTIVE_PATTERN_CLASSES
) -> np.ndarray:
    """Build single 161-dimensional input feature vector for next-day forecast."""
    if len(hist_patterns) != PSF_WINDOW_SIZE:
        raise ValueError(f"PSF expects exactly {PSF_WINDOW_SIZE} historical pattern IDs.")
        
    hist_one_hots = [
        one_hot_encode_pattern(p, pattern_to_class_idx, num_classes)
        for p in hist_patterns
    ]
    hist_vec = np.concatenate(hist_one_hots)
    dow_norm = float(target_day_of_week) / 6.0
    month_norm = float(target_month) / 12.0
    
    features = np.concatenate([hist_vec, [dow_norm, month_norm]])
    return features.reshape(1, -1).astype(np.float32)
