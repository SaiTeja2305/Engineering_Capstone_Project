"""Self-Organizing Map (SOM) Clustering Module
Groups 96-dimensional daily electricity profiles into 2D grid patterns using MiniSom.
"""

from pathlib import Path
from typing import Dict, List, Optional, Tuple
import joblib
import numpy as np
from minisom import MiniSom
from src.config import (
    ACTIVE_PATTERN_CLASSES,
    MODELS_DIR,
    SOM_GRID_X,
    SOM_GRID_Y,
    SOM_INPUT_LEN,
    SOM_ITERATIONS,
    SOM_LEARNING_RATE,
    SOM_RANDOM_SEED,
    SOM_SIGMA,
    SOM_SUBSAMPLE_STEP,
)


class SOMClusterer:
    """Manages the 10x10 Self-Organizing Map for load pattern categorization."""

    def __init__(
        self,
        grid_x: int = SOM_GRID_X,
        grid_y: int = SOM_GRID_Y,
        input_len: int = SOM_INPUT_LEN,
        sigma: float = SOM_SIGMA,
        learning_rate: float = SOM_LEARNING_RATE,
        random_seed: int = SOM_RANDOM_SEED
    ):
        self.grid_x = grid_x
        self.grid_y = grid_y
        self.input_len = input_len
        self.sigma = sigma
        self.learning_rate = learning_rate
        self.random_seed = random_seed
        self.som: Optional[MiniSom] = None
        self.active_pattern_ids: List[int] = []
        self.pattern_to_class_idx: Dict[int, int] = {}
        self.class_idx_to_pattern: Dict[int, int] = {}
        self.node_counts: Dict[int, int] = {}

    @property
    def is_trained(self) -> bool:
        """Check whether the SOM has been fitted and has active patterns."""
        return self.som is not None and len(self.active_pattern_ids) > 0

    def build_som(self) -> MiniSom:

        """Instantiate the MiniSom object with standard seeds."""
        som = MiniSom(
            x=self.grid_x,
            y=self.grid_y,
            input_len=self.input_len,
            sigma=self.sigma,
            learning_rate=self.learning_rate,
            random_seed=self.random_seed
        )
        return som

    def train(
        self,
        train_scaled: np.ndarray,
        subsample_step: int = SOM_SUBSAMPLE_STEP,
        num_iterations: int = SOM_ITERATIONS
    ) -> Dict:
        """Train SOM on computationally reduced subset (train_scaled[::5])."""
        self.som = self.build_som()
        
        # Subsample for training efficiency as described in experiment
        training_subset = train_scaled[::subsample_step]
        self.som.pca_weights_init(training_subset)
        self.som.train_random(training_subset, num_iteration=num_iterations, verbose=False)
        
        # Map all training profiles to identify active pattern IDs and counts
        pattern_ids = self.map_profiles_to_patterns(train_scaled)
        unique_patterns, counts = np.unique(pattern_ids, return_counts=True)
        
        self.active_pattern_ids = sorted([int(p) for p in unique_patterns])
        self.node_counts = {int(p): int(c) for p, c in zip(unique_patterns, counts)}
        
        # Map each active pattern to a 0-indexed class index (for ANN one-hot)
        self.pattern_to_class_idx = {p: idx for idx, p in enumerate(self.active_pattern_ids)}
        self.class_idx_to_pattern = {idx: p for p, idx in self.pattern_to_class_idx.items()}
        
        return {
            "num_profiles_trained": len(training_subset),
            "iterations": num_iterations,
            "total_nodes": self.grid_x * self.grid_y,
            "active_pattern_count": len(self.active_pattern_ids),
            "top_patterns": sorted(self.node_counts.items(), key=lambda x: x[1], reverse=True)[:5]
        }

    def get_pattern_id(self, x: np.ndarray) -> int:
        """Return 1D pattern ID: row * 10 + col from Best Matching Unit (BMU)."""
        if self.som is None:
            raise RuntimeError("SOM is not initialized or trained.")
        bmu = self.som.winner(x)
        return int(bmu[0] * self.grid_y + bmu[1])

    def map_profiles_to_patterns(self, profiles_scaled: np.ndarray) -> np.ndarray:
        """Batch mapping of 96-reading profiles to 1D pattern IDs."""
        if self.som is None:
            raise RuntimeError("SOM is not initialized or trained.")
        pattern_ids = np.zeros(len(profiles_scaled), dtype=int)
        for i, profile in enumerate(profiles_scaled):
            pattern_ids[i] = self.get_pattern_id(profile)
        return pattern_ids

    def get_prototype_curve(self, pattern_id: int) -> np.ndarray:
        """Retrieve the 96-dimensional prototype centroid for a given pattern ID."""
        if self.som is None:
            raise RuntimeError("SOM is not initialized or trained.")
        row = pattern_id // self.grid_y
        col = pattern_id % self.grid_y
        return self.som.get_weights()[row, col]

    def save(self, filepath: str = None):
        """Persist SOM weights and active patterns metadata to disk."""
        if filepath is None:
            MODELS_DIR.mkdir(parents=True, exist_ok=True)
            filepath = MODELS_DIR / "som_clusterer.joblib"
        data = {
            "weights": self.som.get_weights() if self.som else None,
            "active_pattern_ids": self.active_pattern_ids,
            "pattern_to_class_idx": self.pattern_to_class_idx,
            "class_idx_to_pattern": self.class_idx_to_pattern,
            "node_counts": self.node_counts,
            "grid_x": self.grid_x,
            "grid_y": self.grid_y,
            "input_len": self.input_len
        }
        joblib.dump(data, filepath)

    def load(self, filepath: str = None):
        """Load persisted SOM weights and restore state."""
        if filepath is None:
            filepath = MODELS_DIR / "som_clusterer.joblib"
        data = joblib.load(filepath)
        self.grid_x = data["grid_x"]
        self.grid_y = data["grid_y"]
        self.input_len = data["input_len"]
        self.active_pattern_ids = data["active_pattern_ids"]
        self.pattern_to_class_idx = data["pattern_to_class_idx"]
        self.class_idx_to_pattern = data["class_idx_to_pattern"]
        self.node_counts = data["node_counts"]
        
        self.som = self.build_som()
        if data["weights"] is not None:
            self.som._weights = data["weights"]
