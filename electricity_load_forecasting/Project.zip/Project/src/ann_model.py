"""Artificial Neural Network (ANN) Next-Pattern Classifier
Implements Baseline and GA-Optimized Keras architectures with pattern classification and persistence.
"""

from pathlib import Path
from typing import Dict, Optional, Tuple
import numpy as np
from src.config import (
    ACTIVE_PATTERN_CLASSES,
    ANN_TOTAL_INPUT_FEATURES,
    BASELINE_CONFIG,
    GA_OPTIMIZED_CONFIG,
    MODELS_DIR,
)


def build_ann_model(
    input_dim: int = ANN_TOTAL_INPUT_FEATURES,
    hidden_neurons: int = 20,
    output_classes: int = ACTIVE_PATTERN_CLASSES,
    learning_rate: float = 0.001,
    hidden_activation: str = "sigmoid",
    output_activation: str = "softmax"
):
    """Build and compile the Keras Sequential model aligned with the research adaptation."""
    import tensorflow as tf
    from tensorflow.keras.layers import Dense, Input
    from tensorflow.keras.models import Sequential
    from tensorflow.keras.optimizers import Adam

    model = Sequential([
        Input(shape=(input_dim,)),
        Dense(hidden_neurons, activation=hidden_activation, name="hidden_layer"),
        Dense(output_classes, activation=output_activation, name="output_pattern_layer")
    ])

    optimizer = Adam(learning_rate=learning_rate)
    model.compile(
        optimizer=optimizer,
        loss="categorical_crossentropy",
        metrics=["accuracy"]
    )
    return model


class PatternPredictorANN:
    """ANN wrapper for training, predicting, and persisting the next-pattern classifier."""

    def __init__(
        self,
        model_type: str = "baseline",
        hidden_neurons: Optional[int] = None,
        learning_rate: Optional[float] = None,
        input_dim: int = ANN_TOTAL_INPUT_FEATURES,
        output_classes: int = ACTIVE_PATTERN_CLASSES
    ):
        self.model_type = model_type
        if model_type == "ga_optimized":
            cfg = GA_OPTIMIZED_CONFIG
            self.hidden_neurons = hidden_neurons or cfg["hidden_neurons"]
            self.learning_rate = learning_rate or cfg["learning_rate"]
        else:
            cfg = BASELINE_CONFIG
            self.hidden_neurons = hidden_neurons or cfg["hidden_neurons"]
            self.learning_rate = learning_rate or cfg["learning_rate"]

        self.input_dim = input_dim
        self.output_classes = output_classes
        self.model = None

    @property
    def is_trained(self) -> bool:
        """Check whether the ANN model has been constructed/trained."""
        return self.model is not None

    def initialize_model(self):

        """Construct the compiled Keras model."""
        self.model = build_ann_model(
            input_dim=self.input_dim,
            hidden_neurons=self.hidden_neurons,
            output_classes=self.output_classes,
            learning_rate=self.learning_rate
        )

    def train(
        self,
        X_train: np.ndarray,
        y_train: np.ndarray,
        epochs: int = 150,
        batch_size: int = 128,
        validation_split: float = 0.1,
        verbose: int = 0
    ) -> Dict:
        """Train ANN model on PSF sequence feature matrix."""
        if self.model is None:
            self.initialize_model()

        history = self.model.fit(
            X_train,
            y_train,
            epochs=epochs,
            batch_size=batch_size,
            validation_split=validation_split,
            verbose=verbose
        )
        return history.history

    def predict_pattern_class(self, X: np.ndarray) -> int:
        """Predict highest probability pattern class index for given sequence."""
        if self.model is None:
            self.initialize_model()
        probabilities = self.model.predict(X, verbose=0)
        return int(np.argmax(probabilities, axis=1)[0])

    def save(self, filepath: Optional[Path] = None):
        """Save model weights to disk."""
        MODELS_DIR.mkdir(parents=True, exist_ok=True)
        if filepath is None:
            filename = f"ann_{self.model_type}.keras"
            filepath = MODELS_DIR / filename
        if self.model is not None:
            self.model.save(filepath)

    def load(self, filepath: Optional[Path] = None):
        """Load model weights from disk."""
        import tensorflow as tf
        if filepath is None:
            filename = f"ann_{self.model_type}.keras"
            filepath = MODELS_DIR / filename
        if filepath.exists():
            self.model = tf.keras.models.load_model(filepath)
        if filepath.exists():
            self.model = tf.keras.models.load_model(filepath)
