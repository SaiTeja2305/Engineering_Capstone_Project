"""Fluvius 2024 Residential Electricity Load Dataset Loader
Chunked / Streaming Ingestion, Local Wall-Clock Time parsing, and DST Handling.

Schema:
    EAN_ID | Datum | Datum_Startuur | Volume_Afname_KWh | Volume_Injectie_KWh
    Warmtepomp_Indicator | Elektrisch_Voertuig_Indicator | PV_Installatie_Indicator | Contract_Categorie

Target:
    Volume_Afname_KWh (15-minute residential electricity consumption)

Invariants:
    - 366 days in 2024 (leap year)
    - Exactly 96 intervals per day (00:00 to 23:45)
    - March 31 (DST start): interpolate missing 02:00, 02:15, 02:30, 02:45
    - October 27 (DST end): collapse duplicate local intervals via mean aggregation
"""

import io
import zipfile
from typing import Dict, List, Optional, Tuple, Union, Callable
from pathlib import Path
import numpy as np
import pandas as pd

from src.config import (
    FLUVIUS_CATEGORIES,
    READINGS_PER_DAY,
    RANDOM_STATE,
    TOTAL_DAYS,
    TARGET_COLUMN
)
from src.daily_profiles import TIME_SLOT_COLUMNS


def normalize_time_slot(time_val: str) -> str:
    """Normalize timestamp or start-hour value to HH:MM wall-clock string.
    Strips trailing 'Z' and treats as local Brussels wall-clock time.
    
    Examples:
        '01:45:00' -> '01:45'
        '2024-03-31T01:45:00Z' -> '01:45'
        '01:45' -> '01:45'
    """
    if pd.isna(time_val):
        return "00:00"
    s = str(time_val).strip()
    if s.endswith("Z") or s.endswith("z"):
        s = s[:-1]
    if "T" in s:
        s = s.split("T")[1]
    elif " " in s:
        parts = s.split(" ")
        if len(parts) > 1:
            s = parts[1]
    tokens = s.split(":")
    if len(tokens) >= 2:
        return f"{int(tokens[0]):02d}:{int(tokens[1]):02d}"
    return "00:00"


def find_category_for_filename(filename: str) -> Optional[dict]:
    """Match CSV filename to one of the 8 Fluvius categories."""
    base_name = Path(filename).name.lower()
    for cat in FLUVIUS_CATEGORIES:
        if cat["csv_file"].lower() in base_name:
            return cat
    # Partial matching fallback
    for cat in FLUVIUS_CATEGORIES:
        key_part = cat["csv_file"].replace("P6269_Open_Data_", "").replace(".csv", "").lower()
        if key_part in base_name:
            return cat
    return None


def sample_eans_from_csv(
    file_obj,
    n_sample: int = 30,
    random_state: int = RANDOM_STATE
) -> List[str]:
    """Sample reproducible EAN IDs from CSV using random_state."""
    unique_eans = set()
    # Read only EAN_ID column in chunks
    try:
        if hasattr(file_obj, "seek"):
            file_obj.seek(0)
        chunk_iter = pd.read_csv(
            file_obj,
            usecols=["EAN_ID"],
            chunksize=100000,
            dtype={"EAN_ID": str}
        )
        for chunk in chunk_iter:
            unique_eans.update(chunk["EAN_ID"].dropna().unique())
            if len(unique_eans) >= 300:
                break
    except Exception:
        # Fallback with separator autodetection
        if hasattr(file_obj, "seek"):
            file_obj.seek(0)
        df_sample = pd.read_csv(file_obj, nrows=10000, sep=None, engine="python", dtype=str)
        ean_col = [c for c in df_sample.columns if "EAN" in c.upper()]
        if ean_col:
            unique_eans.update(df_sample[ean_col[0]].dropna().unique())

    sorted_eans = sorted(list(unique_eans))
    if not sorted_eans:
        return []
    
    rng = np.random.RandomState(random_state)
    sample_size = min(n_sample, len(sorted_eans))
    selected = rng.choice(sorted_eans, size=sample_size, replace=False).tolist()
    return sorted(selected)


def process_fluvius_csv_to_profiles(
    file_obj,
    category_meta: dict,
    selected_eans: List[str]
) -> pd.DataFrame:
    """Process a single Fluvius CSV into standardized 96-interval daily profiles.
    
    Handles:
    - Long-format CSV reading in streaming chunks
    - Brussels wall-clock time parsing (strip trailing Z)
    - March 31 DST missing 4 slots (02:00, 02:15, 02:30, 02:45) via linear interpolation
    - October 27 DST duplicate local intervals collapsed via mean aggregation
    - Ensures exactly 366 days per selected consumer in 2024
    """
    if hasattr(file_obj, "seek"):
        file_obj.seek(0)
        
    ean_set = set(selected_eans)
    records = []
    
    # Try reading with chunksize
    try:
        chunk_iter = pd.read_csv(
            file_obj,
            usecols=lambda c: c in ["EAN_ID", "Datum", "Datum_Startuur", TARGET_COLUMN],
            chunksize=50000,
            dtype={"EAN_ID": str, "Datum": str, "Datum_Startuur": str}
        )
        for chunk in chunk_iter:
            if TARGET_COLUMN not in chunk.columns:
                continue
            filtered = chunk[chunk["EAN_ID"].isin(ean_set)].copy()
            if not filtered.empty:
                filtered[TARGET_COLUMN] = pd.to_numeric(
                    filtered[TARGET_COLUMN].astype(str).str.replace(",", "."),
                    errors="coerce"
                )
                records.append(filtered)
    except Exception as e:
        # Fallback if delimiter is semicolon
        if hasattr(file_obj, "seek"):
            file_obj.seek(0)
        chunk_iter = pd.read_csv(
            file_obj,
            sep=";",
            usecols=lambda c: c in ["EAN_ID", "Datum", "Datum_Startuur", TARGET_COLUMN],
            chunksize=50000,
            dtype={"EAN_ID": str, "Datum": str, "Datum_Startuur": str}
        )
        for chunk in chunk_iter:
            if TARGET_COLUMN not in chunk.columns:
                continue
            filtered = chunk[chunk["EAN_ID"].isin(ean_set)].copy()
            if not filtered.empty:
                filtered[TARGET_COLUMN] = pd.to_numeric(
                    filtered[TARGET_COLUMN].astype(str).str.replace(",", "."),
                    errors="coerce"
                )
                records.append(filtered)

    if not records:
        return pd.DataFrame()
        
    df_raw = pd.concat(records, ignore_index=True)
    df_raw["TimeSlot"] = df_raw["Datum_Startuur"].apply(normalize_time_slot)
    
    # Clean Datum to YYYY-MM-DD
    df_raw["DateStr"] = pd.to_datetime(df_raw["Datum"]).dt.strftime("%Y-%m-%d")
    
    # Generate all 366 dates in 2024
    dates_2024 = pd.date_range("2024-01-01", "2024-12-31", freq="D").strftime("%Y-%m-%d")
    
    all_cat_profiles = []
    
    for ean in selected_eans:
        cust_sub = df_raw[df_raw["EAN_ID"] == ean]
        if cust_sub.empty:
            continue
            
        # Pivot: index=DateStr, columns=TimeSlot
        # October 27 duplicate intervals are collapsed via aggfunc="mean"
        pivot = cust_sub.pivot_table(
            index="DateStr",
            columns="TimeSlot",
            values=TARGET_COLUMN,
            aggfunc="mean"
        )
        
        # Ensure all 366 calendar dates of 2024 are present in the index
        pivot = pivot.reindex(dates_2024)
        
        # March 31: 02:00, 02:15, 02:30, 02:45 will be NaN
        # Ensure all 96 standard time slot columns are present
        for col in TIME_SLOT_COLUMNS:
            if col not in pivot.columns:
                pivot[col] = np.nan
        pivot = pivot[TIME_SLOT_COLUMNS]
        
        # Interpolate missing slots across time (handles March 31 missing slots)
        pivot = pivot.interpolate(method="linear", axis=1).bfill(axis=1).ffill(axis=1)
        
        # If any entire date was missing, interpolate across days
        pivot = pivot.interpolate(method="linear", axis=0).bfill(axis=0).ffill(axis=0)
        
        # Final safety: fill any residual NaNs with 0.0
        pivot = pivot.fillna(0.0)
        
        # Format matching daily_profiles standard
        pivot = pivot.reset_index().rename(columns={"index": "Date"})
        pivot["Date"] = pd.to_datetime(pivot["Date"])
        pivot.insert(0, "Customer", ean)
        pivot.insert(2, "DayOfWeek", pivot["Date"].dt.dayofweek)
        pivot.insert(3, "Month", pivot["Date"].dt.month)
        pivot.insert(4, "Category", category_meta["name"])
        
        all_cat_profiles.append(pivot)
        
    if not all_cat_profiles:
        return pd.DataFrame()
        
    return pd.concat(all_cat_profiles, ignore_index=True)


def load_fluvius_from_zip(
    zip_source: Union[str, Path, io.BytesIO, bytes],
    consumers_per_cat: int = 30,
    random_state: int = RANDOM_STATE,
    status_callback: Optional[Callable[[str], None]] = None
) -> Tuple[pd.DataFrame, Dict[str, int]]:
    """Process a Fluvius ZIP archive (Part 1 or Part 2) into daily profiles."""
    if isinstance(zip_source, (str, Path)):
        zf = zipfile.ZipFile(zip_source, "r")
    elif isinstance(zip_source, bytes):
        zf = zipfile.ZipFile(io.BytesIO(zip_source), "r")
    else:
        zf = zipfile.ZipFile(zip_source, "r")

    category_counts = {}
    profile_frames = []

    file_list = zf.namelist()
    csv_files = [f for f in file_list if f.lower().endswith(".csv") and not f.startswith("__MACOSX")]
    
    for filename in csv_files:
        cat_meta = find_category_for_filename(filename)
        if not cat_meta:
            continue
            
        cat_name = cat_meta["name"]
        if status_callback:
            status_callback(f"Sampling {consumers_per_cat} consumers from {cat_name} ({filename})...")
            
        with zf.open(filename) as csv_file:
            selected_eans = sample_eans_from_csv(csv_file, n_sample=consumers_per_cat, random_state=random_state)
            
        if not selected_eans:
            continue
            
        if status_callback:
            status_callback(f"Processing daily profiles for {cat_name} ({len(selected_eans)} consumers)...")
            
        with zf.open(filename) as csv_file:
            df_cat = process_fluvius_csv_to_profiles(csv_file, cat_meta, selected_eans)
            
        if not df_cat.empty:
            profile_frames.append(df_cat)
            category_counts[cat_name] = len(selected_eans)

    zf.close()

    if profile_frames:
        combined = pd.concat(profile_frames, ignore_index=True)
        combined = combined.sort_values(["Customer", "Date"]).reset_index(drop=True)
        return combined, category_counts
    return pd.DataFrame(), category_counts


def generate_fluvius_demo_profiles(
    consumers_per_category: int = 1,
    random_state: int = RANDOM_STATE,
    days: int = 366
) -> pd.DataFrame:
    """Generate realistic Fluvius 2024 synthetic profiles for immediate offline testing.
    
    Satisfies all Fluvius invariants:
    - 8 residential categories
    - Full year 2024 (366 days, Jan 1 to Dec 31)
    - 96 intervals per day (00:00 to 23:45)
    - Realistic residential load profiles (morning peak, evening peak, solar dip, EV surge)
    """
    rng = np.random.RandomState(random_state)
    dates = pd.date_range("2024-01-01", periods=days, freq="D")
    
    # 96-reading base residential curve (00:00 to 23:45 in hours 0.0 to 23.75)
    hours = np.linspace(0, 24, 96, endpoint=False)
    # Base curve: low night ~0.15 kW, morning peak ~0.45 kW around 8am, evening peak ~0.65 kW around 20h
    base_profile = (
        0.12 +
        0.25 * np.exp(-0.5 * ((hours - 8.0) / 1.5) ** 2) +
        0.45 * np.exp(-0.5 * ((hours - 20.0) / 2.0) ** 2)
    )

    frames = []
    
    for cat in FLUVIUS_CATEGORIES:
        cat_id = cat["id"]
        cat_name = cat["name"]
        
        has_solar = "solar" in cat_name.lower() or "zp" in cat_name.lower()
        has_ev = "ev" in cat_name.lower()
        has_wp = "heat pump" in cat_name.lower() or "wp" in cat_name.lower()
        
        for c_idx in range(1, consumers_per_category + 1):
            ean_id = f"EAN_CAT{cat_id}_{c_idx:03d}"
            
            # Category signature adjustments
            cat_curve = base_profile.copy()
            if has_wp:
                # Higher baseline heating throughout winter/shoulder months
                cat_curve += 0.20
            if has_solar:
                # Solar self-consumption reduces net afname during midday (11:00 to 16:00)
                solar_dip = 0.30 * np.exp(-0.5 * ((hours - 13.0) / 2.5) ** 2)
                cat_curve = np.maximum(0.02, cat_curve - solar_dip)
            if has_ev:
                # Evening/night home-charging surge around 22:00 to 02:00
                ev_surge = 0.40 * np.exp(-0.5 * ((hours - 23.0) / 1.8) ** 2)
                cat_curve += ev_surge
                
            # Scale variations per customer
            cust_factor = rng.uniform(0.75, 1.25)
            cust_curve = cat_curve * cust_factor
            
            # Build 366 days matrix
            profile_matrix = np.zeros((days, 96), dtype=np.float32)
            for d_idx, dt in enumerate(dates):
                # Weekend vs weekday factor
                is_weekend = dt.dayofweek >= 5
                day_scale = 1.15 if is_weekend else 1.0
                noise = rng.normal(0, 0.03, size=96)
                daily_vals = np.maximum(0.01, cust_curve * day_scale + noise)
                
                # DST special days check
                if dt.month == 3 and dt.day == 31:
                    # Missing 02:00 to 02:45 interpolated
                    daily_vals[8:12] = (daily_vals[7] + daily_vals[12]) / 2.0
                elif dt.month == 10 and dt.day == 27:
                    # Duplicates averaged out to 96
                    daily_vals[8:12] = daily_vals[8:12] * 0.98
                    
                profile_matrix[d_idx] = daily_vals
                
            df_cust = pd.DataFrame(profile_matrix, columns=TIME_SLOT_COLUMNS)
            df_cust.insert(0, "Customer", ean_id)
            df_cust.insert(1, "Date", dates)
            df_cust.insert(2, "DayOfWeek", dates.dayofweek)
            df_cust.insert(3, "Month", dates.month)
            df_cust.insert(4, "Category", cat_name)
            frames.append(df_cust)
            
    df_result = pd.concat(frames, ignore_index=True)
    return df_result
