"""Session State Management and Auto-Preloader
Guarantees all session variables and ML components are initialized across all Streamlit pages.
Operates on Fluvius 2024 Residential Electricity Load Dataset.
"""

from pathlib import Path
import streamlit as st
import pandas as pd

from src.config import BASE_DIR, DATA_DIR, MODELS_DIR, TRAIN_DAYS
from src.fluvius_loader import generate_fluvius_demo_profiles
from src.daily_profiles import split_daily_profiles_chronologically
from src.preprocessing import DataPreprocessor
from src.som_model import SOMClusterer
from src.ann_model import PatternPredictorANN
from src.ga_optimizer import LightweightGAOptimizer
from src.forecasting import LoadForecaster


def init_session_state():
    """Ensure all required session state variables and ML models are initialized."""
    if "preprocessor" not in st.session_state:
        st.session_state.preprocessor = DataPreprocessor()

    if "som_clusterer" not in st.session_state:
        st.session_state.som_clusterer = SOMClusterer()

    if "baseline_ann" not in st.session_state:
        st.session_state.baseline_ann = PatternPredictorANN(model_type="baseline")

    if "ga_ann" not in st.session_state:
        st.session_state.ga_ann = PatternPredictorANN(model_type="ga_optimized")

    if "ga_optimizer" not in st.session_state:
        st.session_state.ga_optimizer = LightweightGAOptimizer()

    if "forecaster" not in st.session_state:
        st.session_state.forecaster = LoadForecaster(
            som_clusterer=st.session_state.som_clusterer,
            preprocessor=st.session_state.preprocessor,
            baseline_ann=st.session_state.baseline_ann,
            ga_ann=st.session_state.ga_ann
        )

    if "daily_profiles_df" not in st.session_state:
        st.session_state.daily_profiles_df = None

    if "train_df" not in st.session_state:
        st.session_state.train_df = None

    if "test_df" not in st.session_state:
        st.session_state.test_df = None

    # Track dynamic evaluation results from user runs
    if "dynamic_results" not in st.session_state:
        st.session_state.dynamic_results = None

    # Auto-initialize with lightweight Fluvius demo profiles if none are loaded yet
    if st.session_state.daily_profiles_df is None:
        try:
            demo_df = generate_fluvius_demo_profiles(consumers_per_category=1, days=366)
            st.session_state.daily_profiles_df = demo_df
            train_df, test_df = split_daily_profiles_chronologically(
                demo_df, train_days_per_customer=TRAIN_DAYS
            )
            st.session_state.train_df = train_df
            st.session_state.test_df = test_df

            # Fit preprocessor strictly on training data
            train_scaled, _ = st.session_state.preprocessor.fit_transform_train(train_df)
        except Exception:
            pass

    # Auto-load persisted model checkpoints if available on disk
    if not getattr(st.session_state.som_clusterer, "is_trained", False):
        som_file = MODELS_DIR / "som_clusterer.joblib"
        if som_file.exists():
            try:
                st.session_state.som_clusterer.load(som_file)
            except Exception:
                pass

    if not getattr(st.session_state.baseline_ann, "is_trained", False):
        base_file = MODELS_DIR / "ann_baseline.keras"
        if base_file.exists():
            try:
                st.session_state.baseline_ann.load(base_file)
            except Exception:
                pass

    if not getattr(st.session_state.ga_ann, "is_trained", False):
        ga_file = MODELS_DIR / "ann_ga_optimized.keras"
        if ga_file.exists():
            try:
                st.session_state.ga_ann.load(ga_file)
            except Exception:
                pass

    # Ensure forecaster is always synchronized with the current models
    st.session_state.forecaster = LoadForecaster(
        som_clusterer=st.session_state.som_clusterer,
        preprocessor=st.session_state.preprocessor,
        baseline_ann=st.session_state.baseline_ann,
        ga_ann=st.session_state.ga_ann
    )
