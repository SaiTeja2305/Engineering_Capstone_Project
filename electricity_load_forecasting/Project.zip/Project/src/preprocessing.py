"""Preprocessing Pipeline with Strict Training Scaler Fitting
Ensures no data leakage by fitting MinMaxScaler strictly on training profiles.
"""

from typing import Dict, Tuple
import joblib
import numpy as np
import pandas as pd
from sklearn.preprocessing import MinMaxScaler
from src.config import MODELS_DIR
from src.daily_profiles import TIME_SLOT_COLUMNS


class DataPreprocessor:
    """Encapsulates scaling and validation to guarantee zero data leakage."""

    def __init__(self):
        self.scaler = MinMaxScaler(feature_range=(0, 1))
        self.is_fitted = False
        self.feature_names = TIME_SLOT_COLUMNS

    def fit_transform_train(self, train_df: pd.DataFrame) -> Tuple[np.ndarray, Dict]:
        """Fit MinMaxScaler strictly on training daily profile load columns."""
        X_train_raw = train_df[self.feature_names].values.astype(float)
        
        # Fit scaler ONLY on train data
        X_train_scaled = self.scaler.fit_transform(X_train_raw)
        self.is_fitted = True
        
        stats = {
            "num_train_profiles": len(train_df),
            "data_min": float(self.scaler.data_min_.min()),
            "data_max": float(self.scaler.data_max_.max()),
            "feature_range": (0, 1)
        }
        return X_train_scaled, stats

    def transform_test(self, test_df: pd.DataFrame) -> np.ndarray:
        """Transform test data using the fitted training scaler without refitting."""
        if not self.is_fitted:
            raise RuntimeError("Preprocessor must be fitted on training data before transforming test data.")
        X_test_raw = test_df[self.feature_names].values.astype(float)
        return self.scaler.transform(X_test_raw)

    def inverse_transform(self, scaled_values: np.ndarray) -> np.ndarray:
        """Inverse transform scaled 96-point profiles back to original electricity scale."""
        if not self.is_fitted:
            raise RuntimeError("Preprocessor is not fitted yet.")
        scaled_2d = np.atleast_2d(scaled_values)
        return self.scaler.inverse_transform(scaled_2d)

    def save(self, filepath: str = None):
        """Persist fitted scaler to disk."""
        if filepath is None:
            MODELS_DIR.mkdir(parents=True, exist_ok=True)
            filepath = MODELS_DIR / "minmax_scaler.joblib"
        joblib.dump(self.scaler, filepath)

    def load(self, filepath: str = None):
        """Load persisted scaler from disk."""
        if filepath is None:
            filepath = MODELS_DIR / "minmax_scaler.joblib"
        self.scaler = joblib.load(filepath)
        self.is_fitted = True
