"""Test Runner executing all tests in test_fluvius_pipeline.py using standard library."""
import sys
import traceback
from pathlib import Path

# Add project root to sys.path
BASE_DIR = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(BASE_DIR))

import tests.test_fluvius_pipeline as t

test_functions = [
    t.test_category_detection,
    t.test_wall_clock_time_and_dst_normalization,
    t.test_random_consumer_selection_reproducibility,
    t.test_daily_profile_invariants,
    t.test_chronological_train_test_split,
    t.test_minmax_scaler_leakage_prevention,
    t.test_som_clustering_dimensions,
    t.test_psf_window_sequence_builder,
    t.test_ga_configuration_bounds,
    t.test_forecasting_and_evaluation_end_to_end,
    t.test_explicit_train_days_split,
    t.test_100_class_psf_and_ann_dimensions,
    t.test_actual_ga_candidate_evaluation,
    t.test_dynamic_test_set_evaluation
]

passed = 0
failed = 0

print(f"Executing {len(test_functions)} Fluvius Pipeline Verification Tests...")
print("=" * 60)

for fn in test_functions:
    fn_name = fn.__name__
    try:
        fn()
        print(f"  [PASS] {fn_name}")
        passed += 1
    except Exception as e:
        print(f"  [FAIL] {fn_name}: {e}")
        traceback.print_exc()
        failed += 1

print("=" * 60)
print(f"Results: {passed} passed, {failed} failed out of {len(test_functions)} tests.")

if failed > 0:
    sys.exit(1)
else:
    print("ALL TESTS PASSED SUCCESSFULLY! [OK]")

