"""Fluvius Pipeline Unit & Integration Tests
Validates all requirements of Section 29:
- Category detection
- Wall-clock time parsing (strip trailing Z)
- Reproducible consumer sampling (random_state=42)
- DST handling (March 31 interpolation & October 27 collapse)
- Exactly 96 intervals per day and 366 days in 2024
- Chronological train/test split (256 / 110)
- MinMaxScaler fitted strictly on training data
- SOM 10x10 grid clustering
- PSF window size of 3
- ANN input/output dimensions
- GA parameter search bounds
- End-to-end forecasting pipeline execution
"""

import sys
from pathlib import Path
import numpy as np
import pandas as pd

# Ensure project root is in sys.path
BASE_DIR = Path(__file__).resolve().parent.parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from src.config import (
    FLUVIUS_CATEGORIES,
    RANDOM_STATE,
    TOTAL_DAYS,
    READINGS_PER_DAY,
    TRAIN_DAYS,
    TEST_DAYS,
    SOM_GRID_X,
    SOM_GRID_Y,
    PSF_WINDOW_SIZE,
    GA_CONFIG
)
from src.fluvius_loader import (
    find_category_for_filename,
    normalize_time_slot,
    generate_fluvius_demo_profiles,
    sample_eans_from_csv
)
from src.daily_profiles import TIME_SLOT_COLUMNS, split_daily_profiles_chronologically
from src.preprocessing import DataPreprocessor
from src.som_model import SOMClusterer
from src.psf_model import build_psf_sequences
from src.ann_model import PatternPredictorANN
from src.evaluation import evaluate_forecast
from src.forecasting import LoadForecaster


def test_category_detection():
    """Test detection of all 8 Fluvius category CSV filenames."""
    assert len(FLUVIUS_CATEGORIES) == 8
    for cat in FLUVIUS_CATEGORIES:
        detected = find_category_for_filename(cat["csv_file"])
        assert detected is not None, f"Failed to detect {cat['csv_file']}"
        assert detected["id"] == cat["id"]
        assert detected["name"] == cat["name"]


def test_wall_clock_time_and_dst_normalization():
    """Test local Brussels wall-clock time parsing with trailing Z stripped."""
    assert normalize_time_slot("00:00:00") == "00:00"
    assert normalize_time_slot("01:45:00Z") == "01:45"
    assert normalize_time_slot("2024-03-31T01:45:00Z") == "01:45"
    assert normalize_time_slot("2024-10-27 02:30:00") == "02:30"
    assert normalize_time_slot("23:45") == "23:45"


def test_random_consumer_selection_reproducibility():
    """Verify random consumer sampling produces identical results with random_state=42."""
    import io
    dummy_eans = [f"EAN_{i:04d}" for i in range(100)]
    csv_text = "EAN_ID\n" + "\n".join(dummy_eans)
    
    sample1 = sample_eans_from_csv(io.StringIO(csv_text), n_sample=10, random_state=42)
    sample2 = sample_eans_from_csv(io.StringIO(csv_text), n_sample=10, random_state=42)
    sample_diff = sample_eans_from_csv(io.StringIO(csv_text), n_sample=10, random_state=99)
    
    assert sample1 == sample2, "Sampling with random_state=42 must be reproducible"
    assert sample1 != sample_diff, "Different seeds should produce different selections"
    assert len(sample1) == 10


def test_daily_profile_invariants():
    """Verify that daily profiles strictly satisfy 96 intervals and 366 days in 2024."""
    demo_df = generate_fluvius_demo_profiles(consumers_per_category=1, days=366)
    
    # Check total consumers (8 categories x 1)
    assert demo_df["Customer"].nunique() == 8
    
    # Check 96 time columns
    for col in TIME_SLOT_COLUMNS:
        assert col in demo_df.columns
    assert len(TIME_SLOT_COLUMNS) == 96
    
    # Check all days per consumer = 366
    for cust in demo_df["Customer"].unique():
        cust_sub = demo_df[demo_df["Customer"] == cust]
        assert len(cust_sub) == 366
        # Verify no NaN values
        assert not cust_sub[TIME_SLOT_COLUMNS].isna().any().any()


def test_chronological_train_test_split():
    """Verify chronological partition (train days first, test days remaining)."""
    demo_df = generate_fluvius_demo_profiles(consumers_per_category=1, days=366)
    train_df, test_df = split_daily_profiles_chronologically(demo_df, train_days_per_customer=TRAIN_DAYS)
    
    assert len(train_df) == 8 * TRAIN_DAYS
    assert len(test_df) == 8 * TEST_DAYS
    assert len(train_df) + len(test_df) == len(demo_df)
    
    # Chronological invariant check: maximum train date < minimum test date per customer
    for cust in demo_df["Customer"].unique():
        cust_train = train_df[train_df["Customer"] == cust]
        cust_test = test_df[test_df["Customer"] == cust]
        assert cust_train["Date"].max() < cust_test["Date"].min()


def test_minmax_scaler_leakage_prevention():
    """Verify scaler is fitted strictly on training data only."""
    demo_df = generate_fluvius_demo_profiles(consumers_per_category=1, days=100)
    train_df, test_df = split_daily_profiles_chronologically(demo_df, train_days_per_customer=70)
    
    preprocessor = DataPreprocessor()
    train_scaled, stats = preprocessor.fit_transform_train(train_df)
    test_scaled = preprocessor.transform_test(test_df)
    
    # Train scaled strictly in [0, 1]
    assert np.all(train_scaled >= -1e-6)
    assert np.all(train_scaled <= 1.0 + 1e-6)
    assert preprocessor.is_fitted
    
    # Inverse transform recovers original data
    unscaled_train = preprocessor.inverse_transform(train_scaled)
    orig_train_vals = train_df[TIME_SLOT_COLUMNS].values
    np.testing.assert_allclose(unscaled_train, orig_train_vals, atol=1e-4)


def test_som_clustering_dimensions():
    """Verify SOM 10x10 grid clustering and active pattern mapping."""
    demo_df = generate_fluvius_demo_profiles(consumers_per_category=1, days=60)
    train_df, _ = split_daily_profiles_chronologically(demo_df, train_days_per_customer=40)
    
    preprocessor = DataPreprocessor()
    train_scaled, _ = preprocessor.fit_transform_train(train_df)
    
    som = SOMClusterer(grid_x=SOM_GRID_X, grid_y=SOM_GRID_Y, random_seed=42)
    res = som.train(train_scaled, subsample_step=1, num_iterations=200)
    
    assert som.is_trained
    assert res["active_pattern_count"] > 0
    assert res["active_pattern_count"] <= 100
    
    pattern_ids = som.map_profiles_to_patterns(train_scaled)
    assert len(pattern_ids) == len(train_scaled)
    assert all(0 <= pid < 100 for pid in pattern_ids)


def test_psf_window_sequence_builder():
    """Verify PSF sliding window of size 3 creates correct feature matrices."""
    demo_df = generate_fluvius_demo_profiles(consumers_per_category=1, days=50)
    train_df, _ = split_daily_profiles_chronologically(demo_df, train_days_per_customer=40)
    
    preprocessor = DataPreprocessor()
    train_scaled, _ = preprocessor.fit_transform_train(train_df)
    som = SOMClusterer(random_seed=42)
    som.train(train_scaled, subsample_step=1, num_iterations=100)
    
    pattern_ids = som.map_profiles_to_patterns(train_scaled)
    X, y, meta = build_psf_sequences(
        daily_profiles_df=train_df,
        pattern_ids=pattern_ids,
        pattern_to_class_idx=som.pattern_to_class_idx,
        window_size=PSF_WINDOW_SIZE
    )
    
    # Calculate expected sequences per customer
    train_cust_days = len(train_df[train_df["Customer"] == train_df["Customer"].iloc[0]])
    expected_seq_count = 8 * (train_cust_days - PSF_WINDOW_SIZE)
    assert len(X) == expected_seq_count
    assert len(y) == expected_seq_count
    
    # Input dimension = (window * num_classes) + 2 calendar features
    assert X.shape[1] == (PSF_WINDOW_SIZE * 100) + 2


def test_ga_configuration_bounds():
    """Verify GA parameter ranges match project specifications."""
    assert GA_CONFIG["population_size"] == 5
    assert GA_CONFIG["search_space"]["hidden_neurons"] == (5, 40)
    assert GA_CONFIG["search_space"]["learning_rate"] == (0.0001, 0.01)


def test_forecasting_and_evaluation_end_to_end():
    """Verify complete day-ahead forecast and evaluation metrics calculation."""
    demo_df = generate_fluvius_demo_profiles(consumers_per_category=1, days=40)
    train_df, test_df = split_daily_profiles_chronologically(demo_df, train_days_per_customer=30)
    
    preprocessor = DataPreprocessor()
    train_scaled, _ = preprocessor.fit_transform_train(train_df)
    
    som = SOMClusterer(random_seed=42)
    som.train(train_scaled, subsample_step=1, num_iterations=100)
    
    forecaster = LoadForecaster(som_clusterer=som, preprocessor=preprocessor)
    test_cust = test_df["Customer"].iloc[0]
    target_dt = test_df["Date"].iloc[-1]
    
    forecast_res = forecaster.forecast_single_day(
        customer_id=test_cust,
        target_date=target_dt,
        daily_profiles_df=demo_df,
        model_type="baseline"
    )
    
    assert forecast_res is not None
    assert "metrics" in forecast_res
    assert "forecast_df" in forecast_res
    assert len(forecast_res["forecast_df"]) == 96
    
    metrics = forecast_res["metrics"]
    assert "mae" in metrics and metrics["mae"] >= 0
    assert "rmse" in metrics and metrics["rmse"] >= 0
    assert "mape" in metrics and metrics["mape"] >= 0


def test_explicit_train_days_split():
    """Verify explicit train_days_per_customer is strictly honored (e.g. 20/28 not 70%)."""
    demo_df = generate_fluvius_demo_profiles(consumers_per_category=1, days=28)
    train_df, test_df = split_daily_profiles_chronologically(demo_df, train_days_per_customer=20)
    
    # 8 customers * 20 = 160 train rows, 8 * 8 = 64 test rows
    assert len(train_df) == 8 * 20
    assert len(test_df) == 8 * 8
    for cust in demo_df["Customer"].unique():
        cust_train = train_df[train_df["Customer"] == cust]
        cust_test = test_df[test_df["Customer"] == cust]
        assert len(cust_train) == 20
        assert len(cust_test) == 8


def test_100_class_psf_and_ann_dimensions():
    """Verify PSF produces 302-dim features and ANN handles 302 -> 100 dimensions cleanly."""
    demo_df = generate_fluvius_demo_profiles(consumers_per_category=1, days=30)
    train_df, _ = split_daily_profiles_chronologically(demo_df, train_days_per_customer=20)
    
    preprocessor = DataPreprocessor()
    train_scaled, _ = preprocessor.fit_transform_train(train_df)
    som = SOMClusterer(grid_x=10, grid_y=10, random_seed=42)
    som.train(train_scaled, subsample_step=1, num_iterations=50)
    
    pattern_ids = som.map_profiles_to_patterns(train_scaled)
    X, y, _ = build_psf_sequences(train_df, pattern_ids, som.pattern_to_class_idx, window_size=3)
    
    assert X.shape[1] == 302, f"Expected 302 input features (3*100 + 2), got {X.shape[1]}"
    
    ann = PatternPredictorANN(model_type="baseline", input_dim=302, output_classes=100, hidden_neurons=16, learning_rate=0.001)
    ann.initialize_model()
    
    # Forward pass on small batch
    sample_preds = ann.model.predict(X[:5], verbose=0)
    assert sample_preds.shape == (5, 100), f"Expected shape (5, 100), got {sample_preds.shape}"
    np.testing.assert_allclose(sample_preds.sum(axis=1), np.ones(5), atol=1e-5)


def test_actual_ga_candidate_evaluation():
    """Verify GA optimizer actually evaluates candidates and computes real validation RMSE."""
    from src.ga_optimizer import LightweightGAOptimizer
    
    demo_df = generate_fluvius_demo_profiles(consumers_per_category=1, days=30)
    train_df, _ = split_daily_profiles_chronologically(demo_df, train_days_per_customer=20)
    
    preprocessor = DataPreprocessor()
    train_scaled, _ = preprocessor.fit_transform_train(train_df)
    som = SOMClusterer(grid_x=10, grid_y=10, random_seed=42)
    som.train(train_scaled, subsample_step=1, num_iterations=50)
    
    pattern_ids = som.map_profiles_to_patterns(train_scaled)
    X, y, _ = build_psf_sequences(train_df, pattern_ids, som.pattern_to_class_idx, window_size=3)
    
    ga = LightweightGAOptimizer(population_size=3, candidate_epochs=2, random_seed=42)
    best_cand, candidates = ga.run_lightweight_search(X, y, som_clusterer=som, epochs_per_candidate=2)
    
    assert len(candidates) == 3
    for cand in candidates:
        assert cand["val_rmse"] is not None
        assert isinstance(cand["val_rmse"], float)
        assert cand["val_rmse"] > 0
        assert 5 <= cand["hidden_neurons"] <= 40
        assert 0.0001 <= cand["learning_rate"] <= 0.01
        
    min_cand_rmse = min(c["val_rmse"] for c in candidates)
    assert best_cand["val_rmse"] == min_cand_rmse, "Best candidate must match minimum validation RMSE"


def test_dynamic_test_set_evaluation():
    """Verify evaluate_test_set executes full batch evaluation on test partition."""
    demo_df = generate_fluvius_demo_profiles(consumers_per_category=1, days=25)
    train_df, test_df = split_daily_profiles_chronologically(demo_df, train_days_per_customer=15)
    
    preprocessor = DataPreprocessor()
    train_scaled, _ = preprocessor.fit_transform_train(train_df)
    som = SOMClusterer(grid_x=10, grid_y=10, random_seed=42)
    som.train(train_scaled, subsample_step=1, num_iterations=50)
    
    pattern_ids = som.map_profiles_to_patterns(train_scaled)
    X, y, _ = build_psf_sequences(train_df, pattern_ids, som.pattern_to_class_idx, window_size=3)
    
    ann = PatternPredictorANN(model_type="baseline", input_dim=302, output_classes=100)
    ann.train(X, y, epochs=2, batch_size=64, verbose=0)
    
    forecaster = LoadForecaster(som_clusterer=som, preprocessor=preprocessor, baseline_ann=ann)
    eval_res = forecaster.evaluate_test_set(test_df=test_df, daily_profiles_df=demo_df, model_type="baseline")
    
    assert eval_res is not None
    assert eval_res["forecast_count"] > 0
    assert eval_res["mae"] >= 0
    assert eval_res["rmse"] >= 0
    assert eval_res["mape"] >= 0
    assert eval_res["runtime_seconds"] > 0

