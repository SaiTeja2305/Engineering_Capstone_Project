"""Page 7: Experimental Model Comparison
Side-by-side empirical performance evaluation of Baseline vs. GA-Optimized forecasting models.
Operates on the Fluvius 2024 Residential Electricity Load Dataset.
"""

import sys
from pathlib import Path
import streamlit as st
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent.parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from src.config import (
    ASSETS_DIR,
    DATASET_NAME,
    BASELINE_CONFIG,
    GA_OPTIMIZED_CONFIG,
    VALIDATED_FLUVIUS_RESULTS,
    LOAD_UNIT
)
from src.visualization import (
    plot_execution_times,
    plot_model_comparison_metrics,
)
from src.state import init_session_state

st.set_page_config(page_title="Model Comparison", page_icon="⚖️", layout="wide")

# Ensure all session state components are initialized
init_session_state()

# Load CSS
css_path = ASSETS_DIR / "style.css"
if css_path.exists():
    with open(css_path, "r") as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

st.title("⚖️ Experimental Model Comparison")
st.caption(f"{DATASET_NAME} — Baseline PSF + SOM + ANN vs. GA-Optimized Model (240 Consumers)")

st.markdown("---")

# Prominent Honest Scientific Callout
st.markdown(
    f"""
    <div class="viva-box" style="border-left: 4px solid #3b82f6;">
        <div class="viva-box-title" style="color: #60a5fa;">⚖️ Empirical Outcome: No Uniform Improvement Across Metrics</div>
        <p style="font-size: 15px; color: #f8fafc; margin-top: 8px;">
            <strong>GA optimization improved MAPE (54.95% → 49.15%) but resulted in higher MAE and RMSE.</strong>
            <br><br>
            {VALIDATED_FLUVIUS_RESULTS['explanation']}
        </p>
    </div>
    """,
    unsafe_allow_html=True
)

st.markdown("---")

# Section 1: Clean Comparison Table
st.subheader("1. Test Set Performance Comparison Table")
st.caption("Final Verified Fluvius Results (Full 240-Consumer Experiment, 26,400 Forecasts)")

b_metrics = VALIDATED_FLUVIUS_RESULTS["baseline"]
g_metrics = VALIDATED_FLUVIUS_RESULTS["ga"]

comparison_rows = [
    {
        "Evaluation Metric": f"Mean Absolute Error (MAE, {LOAD_UNIT})",
        "Baseline PSF + SOM + ANN": f"{b_metrics['mae']:.4f}",
        "GA-Optimized Model": f"{g_metrics['mae']:.4f}",
        "Delta / Difference": f"+{(g_metrics['mae'] - b_metrics['mae']):.4f} (Baseline Lower)"
    },
    {
        "Evaluation Metric": f"Root Mean Squared Error (RMSE, {LOAD_UNIT})",
        "Baseline PSF + SOM + ANN": f"{b_metrics['rmse']:.4f}",
        "GA-Optimized Model": f"{g_metrics['rmse']:.4f}",
        "Delta / Difference": f"+{(g_metrics['rmse'] - b_metrics['rmse']):.4f} (Baseline Lower)"
    },
    {
        "Evaluation Metric": "Mean Absolute Percentage Error (MAPE)",
        "Baseline PSF + SOM + ANN": f"{b_metrics['mape']:.2f}%",
        "GA-Optimized Model": f"{g_metrics['mape']:.2f}%",
        "Delta / Difference": f"{(g_metrics['mape'] - b_metrics['mape']):.2f}% (GA Lower / Improved)"
    },
    {
        "Evaluation Metric": "Pipeline Execution Time (seconds)",
        "Baseline PSF + SOM + ANN": f"{VALIDATED_FLUVIUS_RESULTS['runtime_breakdown']['baseline_pipeline']:.1f} s",
        "GA-Optimized Model": f"{VALIDATED_FLUVIUS_RESULTS['runtime_breakdown']['ga_and_improved_ann']:.1f} s",
        "Delta / Difference": "GA includes hyperparameter search"
    }
]

df_comp = pd.DataFrame(comparison_rows)
st.dataframe(df_comp, use_container_width=True, hide_index=True)

# Dynamic Results Section (If user has run new evaluation in session)
if st.session_state.get("dynamic_results") is not None:
    st.markdown("---")
    st.subheader("⚡ Newly Calculated Results (Active Session Run)")
    st.caption("Dynamically generated from current dataset in memory")
    dyn_res = st.session_state.dynamic_results
    st.dataframe(pd.DataFrame(dyn_res), use_container_width=True)

st.markdown("---")

# Section 2: Visual Comparison
st.subheader("2. Comparative Performance Visualizations")
col_chart1, col_chart2 = st.columns([1.5, 1])

with col_chart1:
    fig_metrics = plot_model_comparison_metrics()
    st.plotly_chart(fig_metrics, use_container_width=True)

with col_chart2:
    fig_time = plot_execution_times()
    st.plotly_chart(fig_time, use_container_width=True)

st.markdown("---")

# Section 3: Architecture Differences Table
st.subheader("3. Architectural Differences")
arch_data = {
    "Hyperparameter / Layer": [
        "Forecasting Methodology",
        "SOM Clustering Grid",
        "PSF History Window ($W$)",
        "Hidden Layer Neurons",
        "Hidden Activation Function",
        "Optimizer & Initial Learning Rate",
        "Validation RMSE during Search",
        "Loss Function",
        "Epochs / Batch Size"
    ],
    "Baseline PSF + SOM + ANN": [
        "Pattern Sequence-Based (PSF)",
        "10 × 10 Grid (100 nodes)",
        f"{BASELINE_CONFIG['psf_window']} Days",
        f"{BASELINE_CONFIG['hidden_neurons']} Neurons",
        BASELINE_CONFIG["hidden_activation"].capitalize(),
        f"Adam (lr = {BASELINE_CONFIG['learning_rate']})",
        "— (Default baseline architecture)",
        "Categorical Cross-Entropy",
        f"{BASELINE_CONFIG['epochs']} Epochs / Batch {BASELINE_CONFIG['batch_size']}"
    ],
    "GA-Optimized Model": [
        "Pattern Sequence-Based (PSF)",
        "10 × 10 Grid (100 nodes)",
        f"{BASELINE_CONFIG['psf_window']} Days",
        f"{VALIDATED_FLUVIUS_RESULTS['ga']['selected_hidden_neurons']} Neurons (GA Selected)",
        BASELINE_CONFIG["hidden_activation"].capitalize(),
        f"Adam (lr = {VALIDATED_FLUVIUS_RESULTS['ga']['selected_learning_rate']:.7f})",
        f"{VALIDATED_FLUVIUS_RESULTS['ga']['val_rmse']:.4f} {LOAD_UNIT}",
        "Categorical Cross-Entropy",
        f"{BASELINE_CONFIG['epochs']} Epochs / Batch {BASELINE_CONFIG['batch_size']}"
    ]
}
st.dataframe(pd.DataFrame(arch_data), use_container_width=True, hide_index=True)
