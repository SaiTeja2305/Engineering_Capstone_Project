"""Page 6: Genetic Algorithm (GA) Hyperparameter Optimization
Visualizes the lightweight GA evolutionary candidates, chromosome fitness, and hyperparameter selection.
Operates on the Fluvius 2024 Residential Electricity Load Dataset.
"""

import sys
from pathlib import Path
import streamlit as st
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent.parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from src.config import (
    ASSETS_DIR,
    GA_CANDIDATES,
    GA_CONFIG,
    GA_OPTIMIZED_CONFIG,
    VALIDATED_FLUVIUS_RESULTS,
    LOAD_UNIT
)
from src.visualization import plot_ga_candidate_fitness
from src.state import init_session_state

st.set_page_config(page_title="GA Hyperparameter Optimization", page_icon="🧬", layout="wide")

# Ensure all session state components are initialized
init_session_state()

# Load CSS
css_path = ASSETS_DIR / "style.css"
if css_path.exists():
    with open(css_path, "r") as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

st.title("🧬 Lightweight Genetic Algorithm (GA) Optimization")
st.caption("Evolutionary search for ANN hidden neurons and learning rate using Validation RMSE fitness")

st.markdown("---")

st.markdown(
    """
    <div style="background-color: #1a2234; border-left: 4px solid #f59e0b; padding: 12px 18px; border-radius: 6px; margin-bottom: 20px;">
        <span style="font-size: 15px; color: #f8fafc;">
            💡 <strong>Key Architectural Principle:</strong> The Genetic Algorithm searches for ANN hyperparameters that minimize forecasting error on validation data.
            <strong>GA is an optimization method. It does NOT directly forecast electricity.</strong>
        </span>
    </div>
    """,
    unsafe_allow_html=True
)

st.markdown(
    """
    > ⚠️ **Project Adaptation Notice:**  
    > In our adapted Fluvius experiment, **SOM dimensions (10×10)** and **PSF window ($W=3$)** are fixed,
    > and the GA searches over the ANN hidden neurons ($5–40$) and learning rate ($0.0001–0.01$).
    > This is our project adaptation and does not claim to be an exact reproduction of the entire paper's broader GA search.
    """
)

# Search Space Specification Cards
c1, c2, c3, c4 = st.columns(4)
c1.metric("Population Size", f"{GA_CONFIG['population_size']} Candidates")
c2.metric("Hidden Neurons Search", "5 to 40")
c3.metric("Learning Rate Search", "0.0001 to 0.01")
c4.metric("Fitness Metric", f"Validation RMSE ({LOAD_UNIT})")

st.markdown("---")

# Validated Candidate Population vs Dynamic Execution
st.subheader("1. Evaluated GA Candidate Chromosomes")
st.caption("Previously Validated Fluvius Results (from 240-Consumer Full Experiment)")

col_left, col_right = st.columns([1.1, 1])

with col_left:
    df_cand = pd.DataFrame(GA_CANDIDATES)
    st.dataframe(
        df_cand.style.apply(
            lambda row: ["background-color: #d1fae5" if row["selected"] else "" for _ in row],
            axis=1
        ),
        use_container_width=True
    )

    g_winner = VALIDATED_FLUVIUS_RESULTS["ga"]
    st.markdown(
        f"""
        <div class="viva-box">
            <div class="viva-box-title">🏆 Selected Chromosome: Candidate 2 (Previously Validated)</div>
            <ul>
                <li><strong>Selected Hidden Neurons:</strong> {g_winner['selected_hidden_neurons']}</li>
                <li><strong>Selected Learning Rate:</strong> {g_winner['selected_learning_rate']:.7f}</li>
                <li><strong>Validation RMSE:</strong> {g_winner['val_rmse']:.4f} {LOAD_UNIT}</li>
                <li><strong>Role:</strong> Configured for the GA-Optimized Model</li>
            </ul>
        </div>
        """,
        unsafe_allow_html=True
    )

with col_right:
    st.markdown("#### Candidate Fitness Comparison (Validation RMSE)")
    fig_fitness = plot_ga_candidate_fitness()
    st.plotly_chart(fig_fitness, use_container_width=True)

st.markdown("---")

st.subheader("2. Comprehensive Evolutionary Viva Defense")
with st.expander("🎓 Why was a lightweight GA adaptation employed instead of an unconstrained multi-day search?"):
    st.markdown(
        """
        - **Paper Scale vs Capstone Scope:** In the original research paper (Criado-Ramón et al., 2023), full unconstrained GA-SOM-NNSF runs
          required upwards of **36,300 seconds (over 10 hours)** on high-performance compute clusters.
        - **Targeted Adaptation:** By fixing SOM at 10×10 and PSF window at $W=3$, we isolated the specific influence of
          ANN capacity (hidden neurons) and gradient step size (learning rate) while keeping validation evaluation tractable.
        - **Honest Generalization Finding:** Optimization on a small validation subset does not guarantee lower error on the full test set.
          This empirical reality is openly documented in our Model Comparison and Results pages.
        """
    )
