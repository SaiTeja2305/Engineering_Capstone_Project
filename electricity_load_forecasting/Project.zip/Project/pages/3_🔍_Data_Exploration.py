"""Page 3: Exploratory Data Analysis & Load Profiling
Interactive visual exploration of Fluvius residential load curves, category distributions,
and 24-hour diurnal patterns across 96 time intervals.
"""

import sys
from pathlib import Path
import streamlit as st
import pandas as pd
import numpy as np
import plotly.graph_objects as go

BASE_DIR = Path(__file__).resolve().parent.parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from src.config import (
    ASSETS_DIR,
    READINGS_PER_DAY,
    DATASET_NAME,
    DATASET_YEAR,
    INTERVAL_MINUTES,
    TOTAL_AVAILABLE_CONSUMERS,
    NUM_CATEGORIES,
    TRAIN_DAYS,
    TEST_DAYS,
    LOAD_UNIT,
    RANDOM_STATE
)
from src.daily_profiles import TIME_SLOT_COLUMNS, split_daily_profiles_chronologically
from src.fluvius_loader import generate_fluvius_demo_profiles
from src.state import init_session_state

st.set_page_config(page_title="Data Exploration & Load Profiles", page_icon="🔍", layout="wide")

# Ensure all session state components are initialized
init_session_state()

# Load CSS
css_path = ASSETS_DIR / "style.css"
if css_path.exists():
    with open(css_path, "r") as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

st.title("🔍 Exploratory Data Analysis & Load Profiling")
st.caption(f"{DATASET_NAME} — Residential Consumption Patterns & Category Archetypes")

st.markdown("---")

if st.session_state.get("daily_profiles_df") is None:
    st.warning("⚠️ No daily profiles loaded yet. Please upload Fluvius ZIP archives or load demo profiles.")
    if st.button("🚀 Load Fluvius Demo Profiles Now"):
        demo_df = generate_fluvius_demo_profiles(consumers_per_category=1, days=366)
        st.session_state.daily_profiles_df = demo_df
        train_df, test_df = split_daily_profiles_chronologically(demo_df, train_days_per_customer=TRAIN_DAYS)
        st.session_state.train_df = train_df
        st.session_state.test_df = test_df
        st.session_state.preprocessor.fit_transform_train(train_df)
        st.rerun()
    st.stop()

daily_df = st.session_state.daily_profiles_df
train_df = st.session_state.train_df
test_df = st.session_state.test_df

# Summary Overview Cards (Section 19 Requirements)
e1, e2, e3, e4, e5, e6 = st.columns(6)
e1.metric("Available Meters", f"{TOTAL_AVAILABLE_CONSUMERS:,}")
e2.metric("Selected Meters", f"{daily_df['Customer'].nunique()}")
e3.metric("Categories", f"{daily_df['Category'].nunique() if 'Category' in daily_df.columns else NUM_CATEGORIES}")
e4.metric("Time Resolution", f"{INTERVAL_MINUTES} min")
e5.metric("Total Daily Profiles", f"{len(daily_df):,}")
train_cnt = len(train_df) if train_df is not None else 0
test_cnt = len(test_df) if test_df is not None else 0
e6.metric("Train / Test Split", f"{train_cnt:,} / {test_cnt:,}")

st.markdown("---")

# Section: Category Distribution Table & Filter
c_table_col, c_ctrl_col = st.columns([1.5, 1])

with c_table_col:
    st.subheader("Category Distribution Breakdown")
    if "Category" in daily_df.columns:
        cat_stats = daily_df.groupby("Category").agg(
            Consumers=("Customer", "nunique"),
            Profiles=("Date", "count"),
            Mean_kWh=("12:00", lambda s: daily_df.loc[s.index, TIME_SLOT_COLUMNS].values.mean())
        ).reset_index()
        cat_stats.columns = ["Consumer Category", "Consumers", "Daily Profiles", f"Avg Load ({LOAD_UNIT})"]
        cat_stats[f"Avg Load ({LOAD_UNIT})"] = cat_stats[f"Avg Load ({LOAD_UNIT})"].round(4)
        st.dataframe(cat_stats, use_container_width=True, hide_index=True)
    else:
        st.info("Profiles loaded without categorical annotations.")

with c_ctrl_col:
    st.subheader("Profile Selector")
    customers = sorted(daily_df["Customer"].unique())
    selected_customer = st.selectbox("Select Consumer Meter", customers, index=0)

    cust_df = daily_df[daily_df["Customer"] == selected_customer].sort_values("Date").reset_index(drop=True)
    available_dates = cust_df["Date"].dt.strftime("%Y-%m-%d").tolist()
    selected_date_str = st.selectbox("Select Profile Date", available_dates, index=min(15, len(available_dates)-1))

# Extract single profile
single_profile_row = cust_df[cust_df["Date"].dt.strftime("%Y-%m-%d") == selected_date_str].iloc[0]
load_values = single_profile_row[TIME_SLOT_COLUMNS].values.astype(float)

# KPI Cards for Selected Profile
max_val = float(np.max(load_values))
max_idx = int(np.argmax(load_values))
peak_time = TIME_SLOT_COLUMNS[max_idx]

min_val = float(np.min(load_values))
min_idx = int(np.argmin(load_values))
min_time = TIME_SLOT_COLUMNS[min_idx]

avg_val = float(np.mean(load_values))
total_val = float(np.sum(load_values))

k1, k2, k3, k4 = st.columns(4)
k1.metric(f"Average Interval Load", f"{avg_val:.3f} {LOAD_UNIT}")
k2.metric("Peak Interval Demand", f"{max_val:.3f} {LOAD_UNIT}", f"at {peak_time}")
k3.metric("Minimum Interval Load", f"{min_val:.3f} {LOAD_UNIT}", f"at {min_time}")
k4.metric("Daily Cumulative Energy", f"{total_val:.2f} {LOAD_UNIT}")

st.markdown("---")

# Visual Tabs (Secondary and clean)
tab1, tab2, tab3 = st.tabs([
    "📊 24-Hour Profile Curve (96 Readings)",
    "📈 Annual Load Trend (2024)",
    "📅 Weekday vs. Weekend Archetype"
])

with tab1:
    fig_single = go.Figure()
    fig_single.add_trace(go.Scatter(
        x=TIME_SLOT_COLUMNS,
        y=load_values,
        mode="lines+markers",
        name=f"{selected_customer} ({selected_date_str})",
        line=dict(color="#2563eb", width=2.5),
        marker=dict(size=4)
    ))
    fig_single.update_layout(
        title=f"<b>24-Hour Electricity Profile (96 Intervals)</b>: {selected_customer} — {selected_date_str}",
        xaxis_title="Time of Day (15-Minute Wall-Clock Intervals)",
        yaxis_title=f"Consumption ({LOAD_UNIT})",
        template="plotly_white",
        hovermode="x unified",
        margin=dict(l=40, r=40, t=50, b=40)
    )
    st.plotly_chart(fig_single, use_container_width=True)

with tab2:
    daily_averages = cust_df[TIME_SLOT_COLUMNS].mean(axis=1)
    daily_peaks = cust_df[TIME_SLOT_COLUMNS].max(axis=1)

    fig_trend = go.Figure()
    fig_trend.add_trace(go.Scatter(
        x=cust_df["Date"],
        y=daily_averages,
        mode="lines",
        name=f"Average Interval ({LOAD_UNIT})",
        line=dict(color="#0284c7", width=2)
    ))
    fig_trend.add_trace(go.Scatter(
        x=cust_df["Date"],
        y=daily_peaks,
        mode="lines",
        name=f"Peak Interval ({LOAD_UNIT})",
        line=dict(color="#f43f5e", width=1.5, dash="dot")
    ))
    fig_trend.update_layout(
        title=f"<b>Annual Consumption Trend (2024)</b>: {selected_customer}",
        xaxis_title="Date",
        yaxis_title=f"Load ({LOAD_UNIT})",
        template="plotly_white",
        hovermode="x unified",
        margin=dict(l=40, r=40, t=50, b=40)
    )
    st.plotly_chart(fig_trend, use_container_width=True)

with tab3:
    weekday_profiles = cust_df[cust_df["DayOfWeek"] < 5][TIME_SLOT_COLUMNS].mean(axis=0)
    weekend_profiles = cust_df[cust_df["DayOfWeek"] >= 5][TIME_SLOT_COLUMNS].mean(axis=0)

    fig_wk = go.Figure()
    fig_wk.add_trace(go.Scatter(
        x=TIME_SLOT_COLUMNS,
        y=weekday_profiles,
        mode="lines",
        name="Average Weekday (Mon–Fri)",
        line=dict(color="#4f46e5", width=2.5)
    ))
    fig_wk.add_trace(go.Scatter(
        x=TIME_SLOT_COLUMNS,
        y=weekend_profiles,
        mode="lines",
        name="Average Weekend (Sat–Sun)",
        line=dict(color="#10b981", width=2.5, dash="dash")
    ))
    fig_wk.update_layout(
        title=f"<b>Diurnal Load Pattern: Weekday vs. Weekend</b> ({selected_customer})",
        xaxis_title="Time of Day",
        yaxis_title=f"Average Load ({LOAD_UNIT})",
        template="plotly_white",
        hovermode="x unified",
        margin=dict(l=40, r=40, t=50, b=40)
    )
    st.plotly_chart(fig_wk, use_container_width=True)
