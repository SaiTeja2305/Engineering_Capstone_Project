"""Page 2: Dataset Upload, Validation & Preprocessing
Ingests Fluvius 2024 Residential Electricity Load Dataset (ZIP Archives or CSVs).
Handles streaming chunked ingestion, local Brussels wall-clock time, and DST transitions.
"""

import sys
from pathlib import Path
import streamlit as st
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent.parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from src.config import (
    ASSETS_DIR,
    DATASET_NAME,
    DATASET_YEAR,
    TOTAL_AVAILABLE_CONSUMERS,
    NUM_CATEGORIES,
    CONSUMERS_PER_CATEGORY_DEFAULT,
    SELECTED_CONSUMERS_DEFAULT,
    READINGS_PER_DAY,
    INTERVAL_MINUTES,
    TOTAL_DAYS,
    TRAIN_DAYS,
    TEST_DAYS,
    FLUVIUS_CATEGORIES,
    TEST_MODE_CONFIG,
    FULL_MODE_CONFIG,
    RANDOM_STATE
)
from src.fluvius_loader import (
    load_fluvius_from_zip,
    generate_fluvius_demo_profiles
)
from src.daily_profiles import split_daily_profiles_chronologically
from src.state import init_session_state
from src.forecasting import LoadForecaster

st.set_page_config(page_title="Dataset Upload & Preprocessing", page_icon="📁", layout="wide")

# Ensure all session state components are initialized
init_session_state()

# Load CSS
css_path = ASSETS_DIR / "style.css"
if css_path.exists():
    with open(css_path, "r") as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

st.title("📁 Dataset Upload & Preprocessing Pipeline")
st.caption(f"{DATASET_NAME} — Belgium Residential Load Profiles")

st.markdown("---")

# Overview KPI Cards
k1, k2, k3, k4, k5, k6, k7, k8 = st.columns(8)
k1.metric("Available Meters", f"{TOTAL_AVAILABLE_CONSUMERS:,}")
k2.metric("Selected Meters", f"{SELECTED_CONSUMERS_DEFAULT}")
k3.metric("Categories", f"{NUM_CATEGORIES}")
k4.metric("Meters / Category", f"{CONSUMERS_PER_CATEGORY_DEFAULT}")
k5.metric("Time Resolution", f"{INTERVAL_MINUTES} min")
k6.metric("Year", f"{DATASET_YEAR}")
k7.metric("Days", f"{TOTAL_DAYS}")
k8.metric("Readings / Day", f"{READINGS_PER_DAY}")

st.markdown("---")

# Section: Mode Selection & 8 Categories Table
col_mode, col_cats = st.columns([1, 2])

with col_mode:
    st.subheader("1. Pipeline Execution Mode")
    exec_mode = st.radio(
        "Select Experiment Mode:",
        ["Full Mode (240 Consumers)", "Test Mode (8 Consumers)"],
        index=0,
        help="Full Mode executes the complete capstone experiment with 30 consumers/category. Test Mode runs a fast 1-consumer/category sanity check."
    )
    if exec_mode == "Full Mode (240 Consumers)":
        active_consumers_per_cat = FULL_MODE_CONFIG["consumers_per_category"]
        active_train_days = FULL_MODE_CONFIG["train_days"]
        active_test_days = FULL_MODE_CONFIG["test_days"]
        st.info(f"**Configuration:** 30 consumers/cat (240 total), {active_train_days} train days, {active_test_days} test days = 366 days.")
    else:
        active_consumers_per_cat = TEST_MODE_CONFIG["consumers_per_category"]
        active_train_days = TEST_MODE_CONFIG["train_days"]
        active_test_days = TEST_MODE_CONFIG["test_days"]
        st.warning(f"**Test Mode Active:** 1 consumer/cat (8 total), {active_train_days} train days, {active_test_days} test days for rapid validation.")

with col_cats:
    st.subheader("8 Residential Consumer Categories")
    cat_df = pd.DataFrame([
        {
            "Category ID": cat["id"],
            "Consumer Type": cat["name"],
            "ZIP Archive": f"Part {cat['zip_part']}",
            "CSV Source File": cat["csv_file"],
            "Total In Dataset": f"{cat['consumers']} meters",
            "Target Sample": f"{active_consumers_per_cat} meters"
        }
        for cat in FLUVIUS_CATEGORIES
    ])
    st.dataframe(cat_df, use_container_width=True, hide_index=True)

st.markdown("---")

# Section: Upload Fluvius Archives or Generate Demo Profiles
st.subheader("2. Fluvius Archive Ingestion")

upload_col1, upload_col2, demo_col = st.columns([1.2, 1.2, 1.0])

with upload_col1:
    st.markdown("**Upload Fluvius Archive (Part 1)**")
    part1_zip = st.file_uploader(
        "Part 1 ZIP (Solar & Heat Pump categories, ~207 MB)",
        type=["zip"],
        key="zip_part1_uploader",
        help="Contains categories: With solar, Without solar, Heat pump + solar, Heat pump without solar."
    )

with upload_col2:
    st.markdown("**Upload Fluvius Archive (Part 2)**")
    part2_zip = st.file_uploader(
        "Part 2 ZIP (EV & Combined categories, ~190 MB)",
        type=["zip"],
        key="zip_part2_uploader",
        help="Contains categories: Solar + EV, No solar + EV, Heat pump + EV + solar, Heat pump + EV without solar."
    )

with demo_col:
    st.markdown("**Synthetic / Demo Generator**")
    st.caption("Generate realistic 2024 Fluvius profiles (Jan–Dec, 96 intervals/day, DST handled) for instant testing.")
    if st.button("🚀 Load Fluvius Demo Profiles", use_container_width=True, type="secondary"):
        with st.spinner("Generating 2024 Fluvius profiles across all 8 categories..."):
            demo_days = active_train_days + active_test_days
            demo_df = generate_fluvius_demo_profiles(
                consumers_per_category=active_consumers_per_cat,
                random_state=RANDOM_STATE,
                days=demo_days
            )
            st.session_state.daily_profiles_df = demo_df
            train_df, test_df = split_daily_profiles_chronologically(
                demo_df, train_days_per_customer=active_train_days
            )
            st.session_state.train_df = train_df
            st.session_state.test_df = test_df
            st.success(f"Generated {len(demo_df):,} daily profiles across {demo_df['Customer'].nunique()} consumers!")
            st.rerun()

# Handle ZIP file upload processing
uploaded_zips = [z for z in [part1_zip, part2_zip] if z is not None]

if uploaded_zips:
    if st.button("⚡ Process Uploaded Fluvius ZIP(s)", type="primary"):
        status_box = st.empty()
        all_zip_profiles = []
        cat_summary = {}

        try:
            for idx, z_file in enumerate(uploaded_zips, 1):
                status_box.info(f"Streaming archive Part {idx} ({z_file.name})...")
                df_zip, counts = load_fluvius_from_zip(
                    z_file,
                    consumers_per_cat=active_consumers_per_cat,
                    random_state=RANDOM_STATE,
                    status_callback=lambda msg: status_box.info(msg)
                )
                if not df_zip.empty:
                    all_zip_profiles.append(df_zip)
                    cat_summary.update(counts)

            if all_zip_profiles:
                combined_profiles = pd.concat(all_zip_profiles, ignore_index=True)
                st.session_state.daily_profiles_df = combined_profiles
                train_df, test_df = split_daily_profiles_chronologically(
                    combined_profiles, train_days_per_customer=active_train_days
                )
                st.session_state.train_df = train_df
                st.session_state.test_df = test_df

                status_box.success(
                    f"✅ Processed {len(combined_profiles):,} daily profiles across {combined_profiles['Customer'].nunique()} consumers! "
                    f"({len(train_df):,} Train / {len(test_df):,} Test profiles)"
                )
                st.rerun()
            else:
                status_box.error("No valid Fluvius category CSV files could be extracted from the uploaded archive(s).")
        except Exception as e:
            status_box.error(f"Error processing archive: {str(e)}")

# Display Processed Daily Profiles Section
if st.session_state.get("daily_profiles_df") is not None:
    daily_df = st.session_state.daily_profiles_df
    train_df = st.session_state.train_df
    test_df = st.session_state.test_df

    st.markdown("---")
    st.subheader("3. Daily Load Profiles & Training Pipeline Trigger")

    p1, p2, p3, p4 = st.columns(4)
    p1.metric("Total Daily Profiles", f"{len(daily_df):,}")
    p2.metric("Active Consumers", f"{daily_df['Customer'].nunique()}")
    p3.metric("Training Profiles", f"{len(train_df):,}")
    p4.metric("Testing Profiles", f"{len(test_df):,}")

    btn_col, info_col = st.columns([1, 2])
    with btn_col:
        if st.button("🧠 Fit Scaler & Train SOM on Profiles", type="primary", use_container_width=True):
            with st.spinner("Fitting MinMaxScaler strictly on train partition and training SOM..."):
                try:
                    # Fit preprocessor strictly on train data to prevent leakage
                    train_scaled, stats = st.session_state.preprocessor.fit_transform_train(train_df)
                    st.session_state.preprocessor.save()

                    # Train SOM on the new profiles
                    subsample = max(1, len(train_scaled) // 2500)
                    som_stats = st.session_state.som_clusterer.train(
                        train_scaled,
                        subsample_step=subsample,
                        num_iterations=1000
                    )
                    st.session_state.som_clusterer.save()

                    # Re-link forecaster
                    st.session_state.forecaster = LoadForecaster(
                        som_clusterer=st.session_state.som_clusterer,
                        preprocessor=st.session_state.preprocessor,
                        baseline_ann=st.session_state.baseline_ann,
                        ga_ann=st.session_state.ga_ann
                    )

                    st.success(
                        f"✅ SOM trained successfully! Active patterns discovered: {som_stats['active_pattern_count']} / 100 nodes."
                    )
                    st.rerun()
                except Exception as e:
                    st.error(f"SOM Training failed: {str(e)}")

    with info_col:
        st.markdown(
            """
            - **DST Invariant Guaranteed:** Exactly **96 intervals** per consumer-day (March 31 interpolated, October 27 collapsed).
            - **Chronological Split:** First 256 days for training (~70%), remaining 110 days for testing (~30%).
            - **Leakage Prevention:** `MinMaxScaler` fitted **strictly on training profiles**.
            """
        )

    st.markdown("#### Daily Profiles Matrix Preview")
    t1, t2 = st.tabs(["Daily Profiles Table (96 Intervals)", "Category & Partition Breakdown"])

    with t1:
        st.caption(f"Displaying {len(daily_df):,} daily profiles (96 time intervals from 00:00 to 23:45 per row)")
        st.dataframe(daily_df, use_container_width=True, height=380)
        csv_data = daily_df.to_csv(index=False).encode("utf-8")
        st.download_button(
            "📥 Download Current Daily Profiles (CSV)",
            data=csv_data,
            file_name="fluvius_daily_profiles.csv",
            mime="text/csv"
        )

    with t2:
        c_left, c_right = st.columns(2)
        with c_left:
            st.markdown("**Profiles per Category:**")
            if "Category" in daily_df.columns:
                cat_summary_df = daily_df.groupby("Category").agg(
                    Consumers=("Customer", "nunique"),
                    TotalProfiles=("Date", "count")
                ).reset_index()
                st.dataframe(cat_summary_df, use_container_width=True, hide_index=True)
        with c_right:
            st.info(f"**Training Partition:** {len(train_df):,} profiles ({daily_df['Customer'].nunique()} consumers × {active_train_days} days)")
            st.info(f"**Testing Partition:** {len(test_df):,} profiles ({daily_df['Customer'].nunique()} consumers × {active_test_days} days)")

# Educational viva callout
with st.expander("🎓 Faculty Viva Notes: Fluvius Ingestion & DST Handling"):
    st.markdown(
        r"""
        - **Why Brussels Local Wall-Clock Time?** Electricity consumer consumption patterns correlate with human lifestyle and local solar noon. Interpreting timestamps as local time ensures that diurnal behaviors (breakfast, dinner, solar peak) occur at consistent interval indices regardless of UTC offsets.
        - **Daylight Saving Time (DST) Handling:**
          - *March 31, 2024 (Spring forward):* 4 missing 15-minute readings (`02:00`, `02:15`, `02:30`, `02:45`) are restored via linear interpolation.
          - *October 27, 2024 (Fall back):* Duplicate readings around `02:00`–`02:45` are collapsed using mean aggregation.
          - *Result:* Every day across all 366 days in 2024 contains **strictly 96 values**.
        - **How is data leakage prevented?** `MinMaxScaler` parameters ($X_{\text{min}}, X_{\text{max}}$) are calculated strictly on the training partition ($N \le 256$ days). The test partition is transformed using the identical fitted scaler.
        """
    )
