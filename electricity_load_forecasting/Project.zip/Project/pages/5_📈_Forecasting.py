"""Page 5: Day-Ahead Electricity Load Forecasting
Pipeline Execution Checklist, Dimension Inspection, and 96-Interval Inference.
Operates on the Fluvius 2024 Residential Electricity Load Dataset.
"""

import sys
from pathlib import Path
import streamlit as st
import pandas as pd
import numpy as np

BASE_DIR = Path(__file__).resolve().parent.parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from src.config import (
    ASSETS_DIR,
    PSF_WINDOW_SIZE,
    SOM_GRID_X,
    SOM_GRID_Y,
    MAX_ACTIVE_PATTERNS,
    TOTAL_DAILY_PROFILES,
    TOTAL_TRAIN_PROFILES,
    TOTAL_TEST_PROFILES,
    LOAD_UNIT,
    TRAIN_DAYS,
    TEST_DAYS
)
from src.visualization import plot_actual_vs_predicted
from src.fluvius_loader import generate_fluvius_demo_profiles
from src.daily_profiles import split_daily_profiles_chronologically
from src.state import init_session_state

st.set_page_config(page_title="Day-Ahead Forecasting", page_icon="📈", layout="wide")

# Ensure all session state components are initialized
init_session_state()

# Load CSS
css_path = ASSETS_DIR / "style.css"
if css_path.exists():
    with open(css_path, "r") as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

st.title("📈 Day-Ahead Electricity Load Forecasting")
st.caption("End-to-End Pipeline Verification, Architectural Shapes, and 96-Interval Profile Prediction")

st.markdown("---")

# Section 1: Pipeline Execution Status Checklist
st.subheader("1. End-to-End Pipeline Execution Status")

# Check status of stages
has_profiles = st.session_state.get("daily_profiles_df") is not None
has_split = st.session_state.get("train_df") is not None and st.session_state.get("test_df") is not None
has_som = getattr(st.session_state.get("som_clusterer"), "is_trained", False)
has_preproc = getattr(st.session_state.get("preprocessor"), "is_fitted", False)
has_base_ann = getattr(st.session_state.get("baseline_ann"), "is_trained", False)
has_ga = getattr(st.session_state.get("ga_ann"), "is_trained", False)
has_eval = st.session_state.get("dynamic_results") is not None


chk_col1, chk_col2, chk_col3 = st.columns(3)

with chk_col1:
    st.markdown(f"{'✅' if has_profiles else '⏳'} **Dataset Loaded**")
    st.markdown(f"{'✅' if has_profiles else '⏳'} **Daily Profiles Generated (96 Intervals)**")
    st.markdown(f"{'✅' if has_split else '⏳'} **Train / Test Chronological Split**")

with chk_col2:
    st.markdown(f"{'✅' if has_som else '⏳'} **SOM Trained (10×10 Grid)**")
    st.markdown(f"{'✅' if has_som else '⏳'} **Load Patterns Discovered**")
    st.markdown(f"{'✅' if has_som else '⏳'} **PSF Sequences Constructed (Window = {PSF_WINDOW_SIZE})**")

with chk_col3:
    st.markdown(f"{'✅' if has_base_ann else '⏳'} **Baseline ANN Ready**")
    st.markdown(f"{'✅' if has_ga else '⏳'} **GA Optimization Evaluated**")
    st.markdown(f"{'✅' if has_eval else '⏳'} **Evaluation Metrics Computed**")

st.markdown("---")

# Section 2: Important Architectural Dimensions & Shapes
st.subheader("2. Pipeline Matrix Dimensions & Configuration")

d1, d2, d3, d4, d5, d6 = st.columns(6)
d1.metric("Daily Profiles", f"{TOTAL_DAILY_PROFILES:,} × 96")
d2.metric("Training Profiles", f"{TOTAL_TRAIN_PROFILES:,}")
d3.metric("Testing Profiles", f"{TOTAL_TEST_PROFILES:,}")
d4.metric("SOM Grid Size", f"{SOM_GRID_X} × {SOM_GRID_Y}")
d5.metric("Max Load Patterns", f"{MAX_ACTIVE_PATTERNS}")
d6.metric("PSF Window ($W$)", f"{PSF_WINDOW_SIZE} Days")

st.markdown("---")

# Fallback if no profiles loaded yet
if not has_profiles:
    st.warning("⚠️ No daily profiles currently in memory. Click below to load Fluvius demo profiles.")
    if st.button("🚀 Load Fluvius Demo Profiles"):
        demo_df = generate_fluvius_demo_profiles(consumers_per_category=1, days=366)
        st.session_state.daily_profiles_df = demo_df
        train_df, test_df = split_daily_profiles_chronologically(demo_df, train_days_per_customer=TRAIN_DAYS)
        st.session_state.train_df = train_df
        st.session_state.test_df = test_df
        train_scaled, _ = st.session_state.preprocessor.fit_transform_train(train_df)
        st.session_state.som_clusterer.train(train_scaled, subsample_step=1, num_iterations=400)
        st.rerun()
    st.stop()

daily_df = st.session_state.daily_profiles_df
customers = sorted(daily_df["Customer"].unique())

# Section 3: Day-Ahead Forecasting Controls
st.subheader("3. Day-Ahead Load Forecast Execution")

c1, c2, c3, c4 = st.columns([1.2, 1.2, 1.2, 1.0])

with c1:
    selected_cust = st.selectbox("Select Consumer Meter", customers, index=0)

cust_profiles = daily_df[daily_df["Customer"] == selected_cust].sort_values("Date").reset_index(drop=True)
available_dates = cust_profiles["Date"].tolist()
valid_dates = available_dates[PSF_WINDOW_SIZE:]

with c2:
    default_idx = min(len(valid_dates) - 1, 260) if len(valid_dates) > 260 else len(valid_dates) - 1
    selected_date = st.selectbox("Select Target Forecast Date", valid_dates, index=default_idx)

with c3:
    model_choice = st.selectbox(
        "Select Forecasting Model",
        ["Baseline (PSF + SOM + ANN)", "GA-Optimized Model"],
        index=0
    )
    model_key = "ga_optimized" if "GA" in model_choice else "baseline"

with c4:
    st.write("")
    st.write("")
    run_forecast_btn = st.button("🚀 Run Day-Ahead Forecast", type="primary", use_container_width=True)

# Generate or Show Forecast
if run_forecast_btn or "last_forecast" in st.session_state:
    if run_forecast_btn or st.session_state.get("last_cust") != selected_cust or st.session_state.get("last_date") != str(selected_date):
        with st.spinner(f"Running inference for {selected_cust} on {selected_date}..."):
            try:
                res = st.session_state.forecaster.forecast_single_day(
                    customer_id=selected_cust,
                    target_date=selected_date,
                    daily_profiles_df=daily_df,
                    model_type=model_key
                )
                st.session_state.last_forecast = res
                st.session_state.last_cust = selected_cust
                st.session_state.last_date = str(selected_date)
            except Exception as e:
                st.error(f"Forecasting error: {str(e)}")
                st.stop()

    forecast_res = st.session_state.get("last_forecast")
    if forecast_res:
        st.markdown("---")
        st.markdown(f"#### Forecast Verification: {forecast_res['customer']} ({forecast_res['date']})")

        # Metric Badges
        metrics = forecast_res.get("metrics", {})
        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Evaluated Model", model_choice.split()[0])
        m2.metric(f"MAE ({LOAD_UNIT})", f"{metrics.get('mae', 0.0):.4f}" if metrics else "N/A")
        m3.metric(f"RMSE ({LOAD_UNIT})", f"{metrics.get('rmse', 0.0):.4f}" if metrics else "N/A")
        m4.metric("MAPE (%)", f"{metrics.get('mape', 0.0):.2f}%" if metrics else "N/A")

        # Sequence attribution card
        hist_p = forecast_res.get("history_patterns", [])
        pred_p = forecast_res.get("predicted_pattern_id")
        if len(hist_p) >= 3:
            st.info(
                f"**PSF Pattern Sequence:** Historical window [Day t-3: Pattern **{hist_p[0]}**, Day t-2: Pattern **{hist_p[1]}**, Day t-1: Pattern **{hist_p[2]}**] "
                f"$\\longrightarrow$ **Predicted Next Day (t): Pattern {pred_p}**"
            )

        # Tabular Readings Table (Primary Information)
        st.markdown("##### 24-Hour Forecast Profile Readings (96 Intervals)")
        st.dataframe(forecast_res["forecast_df"], use_container_width=True, height=260)

        # Optional Plotly Graph inside Expander (Secondary per Section 21)
        with st.expander("📈 View Forecast Visualization (Optional Graph)", expanded=False):
            fig = plot_actual_vs_predicted(
                forecast_df=forecast_res["forecast_df"],
                customer_id=forecast_res["customer"],
                target_date=forecast_res["date"],
                model_name=model_choice,
                metrics=metrics
            )
            st.plotly_chart(fig, use_container_width=True)

        # CSV Export
        csv_bytes = forecast_res["forecast_df"].to_csv(index=False).encode("utf-8")
        st.download_button(
            label=f"📥 Download 96-Point Forecast CSV ({forecast_res['customer']}_{forecast_res['date']}.csv)",
            data=csv_bytes,
            file_name=f"forecast_{forecast_res['customer']}_{forecast_res['date']}.csv",
            mime="text/csv"
        )
