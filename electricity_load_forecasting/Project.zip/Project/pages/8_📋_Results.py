"""Page 8: Results & Faculty Evaluation Report
Official Capstone evaluation summary, Fluvius 2024 results, runtime analysis, and academic reporting.
"""

import sys
from pathlib import Path
import streamlit as st
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent.parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from src.config import (
    ASSETS_DIR,
    BASE_RESEARCH_PAPER,
    DATASET_NAME,
    DATASET_YEAR,
    LOAD_UNIT,
    TOTAL_DAILY_PROFILES,
    VALIDATED_FLUVIUS_RESULTS
)
from src.state import init_session_state

st.set_page_config(page_title="Results & Evaluation", page_icon="📋", layout="wide")

# Ensure all session state components are initialized
init_session_state()

# Load CSS
css_path = ASSETS_DIR / "style.css"
if css_path.exists():
    with open(css_path, "r") as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

st.title("📋 Capstone Results & Faculty Evaluation Summary")
st.caption(f"{DATASET_NAME} — Official Empirical Evaluation & Academic Defense")

st.markdown("---")

# Experiment Scope Cards
st.subheader("1. Experiment Scope & Validated Runtime")
s1, s2, s3, s4, s5 = st.columns(5)
s1.metric("Selected Consumers", f"{VALIDATED_FLUVIUS_RESULTS['consumers']} meters")
s2.metric("Categories", f"{VALIDATED_FLUVIUS_RESULTS['categories']} groups")
s3.metric("Duration", f"{VALIDATED_FLUVIUS_RESULTS['days']} days ({DATASET_YEAR})")
s4.metric("Daily Profiles", f"{VALIDATED_FLUVIUS_RESULTS['profiles']:,}")
s5.metric("Total Runtime", f"≈ {VALIDATED_FLUVIUS_RESULTS['runtime_total_seconds']:.1f} s", VALIDATED_FLUVIUS_RESULTS['runtime_minutes_str'])

# Runtime Breakdown Table
with st.expander("⏱️ Computational Performance & Execution Time Breakdown", expanded=True):
    rb = VALIDATED_FLUVIUS_RESULTS["runtime_breakdown"]
    breakdown_df = pd.DataFrame([
        {"Stage": "1. Archive Discovery & Ingestion", "Execution Time": f"{rb['archive_discovery']:.1f} s", "Description": "ZIP inspection and metadata verification"},
        {"Stage": "2. Streaming & Profile Construction", "Execution Time": f"{rb['streaming_profile_building']:.1f} s", "Description": "Chunked CSV streaming, EAN sampling (seed=42), DST handling"},
        {"Stage": "3. Baseline Pipeline Execution", "Execution Time": f"{rb['baseline_pipeline']:.1f} s", "Description": "MinMaxScaler fit on train, 10×10 SOM, PSF sequences, Baseline ANN"},
        {"Stage": "4. GA Hyperparameter Search & Evaluation", "Execution Time": f"{rb['ga_and_improved_ann']:.1f} s", "Description": "5 candidate evaluations, chromosome selection, final test evaluation"},
        {"Stage": "Total End-to-End Execution", "Execution Time": f"{VALIDATED_FLUVIUS_RESULTS['runtime_total_seconds']:.1f} s", "Description": f"{VALIDATED_FLUVIUS_RESULTS['runtime_minutes_str']}"}
    ])
    st.dataframe(breakdown_df, use_container_width=True, hide_index=True)

st.markdown("---")

# Section 2: Final Verified Evaluation Metrics Cards
st.subheader("2. Final Verified Fluvius Results (240 Consumers × 110 Test Days)")
st.caption("Evaluated on the full chronological test set (240 consumers × 110 test days = 26,400 daily 96-reading forecasts)")

# Read dynamic results from session state if available, else fall back to verified configuration
dynamic_res = st.session_state.get("dynamic_results")
if isinstance(dynamic_res, dict) and dynamic_res.get("baseline") and dynamic_res.get("ga"):
    b_m = dynamic_res["baseline"]
    g_m = dynamic_res["ga"]
    source_label = "Current Live Session Evaluation"
else:
    b_m = VALIDATED_FLUVIUS_RESULTS["baseline"]
    g_m = VALIDATED_FLUVIUS_RESULTS["ga"]
    source_label = "Verified Final Experiment Benchmark"

st.caption(f"Data Source: **{source_label}**")

c1, c2, c3 = st.columns(3)
with c1:
    mae_diff = g_m['mae'] - b_m['mae']
    diff_str = f"+{mae_diff:.4f}" if mae_diff >= 0 else f"{mae_diff:.4f}"
    st.markdown(
        f"""
        <div class="metric-card">
            <div class="metric-card-header">Mean Absolute Error (MAE)</div>
            <div class="metric-card-value">Baseline: {b_m['mae']:.4f} {LOAD_UNIT}</div>
            <div class="metric-card-sub">GA-Optimized: {g_m['mae']:.4f} {LOAD_UNIT} ({diff_str})</div>
        </div>
        """,
        unsafe_allow_html=True
    )
with c2:
    rmse_diff = g_m['rmse'] - b_m['rmse']
    diff_str = f"+{rmse_diff:.4f}" if rmse_diff >= 0 else f"{rmse_diff:.4f}"
    st.markdown(
        f"""
        <div class="metric-card">
            <div class="metric-card-header">Root Mean Squared Error (RMSE)</div>
            <div class="metric-card-value">Baseline: {b_m['rmse']:.4f} {LOAD_UNIT}</div>
            <div class="metric-card-sub">GA-Optimized: {g_m['rmse']:.4f} {LOAD_UNIT} ({diff_str})</div>
        </div>
        """,
        unsafe_allow_html=True
    )
with c3:
    mape_diff = g_m['mape'] - b_m['mape']
    diff_str = f"+{mape_diff:.2f}%" if mape_diff >= 0 else f"{mape_diff:.2f}%"
    st.markdown(
        f"""
        <div class="metric-card">
            <div class="metric-card-header">Mean Absolute Pct Error (MAPE)</div>
            <div class="metric-card-value">Baseline: {b_m['mape']:.2f}%</div>
            <div class="metric-card-sub">GA-Optimized: {g_m['mape']:.2f}% ({diff_str})</div>
        </div>
        """,
        unsafe_allow_html=True
    )

# Required Factual Conclusion
st.markdown(
    f"""
    <div class="viva-box">
        <div class="viva-box-title">📝 Factual Scientific Conclusion</div>
        <p style="font-size: 15px; color: #f8fafc; line-height: 1.6;">
            <strong>"{VALIDATED_FLUVIUS_RESULTS['conclusion']}"</strong>
        </p>
        <p style="font-size: 14px; color: #94a3b8; margin-top: 8px;">
            Scientific integrity requires reporting unmanipulated empirical outcomes.
            GA hyperparameter tuning improved MAPE (54.95% → 49.15%) but resulted in higher MAE (0.1493 kWh vs 0.1157 kWh) and RMSE (0.2169 kWh vs 0.1583 kWh).
            Therefore, GA optimization does not provide a uniform improvement across all error metrics.
        </p>
    </div>
    """,
    unsafe_allow_html=True
)

st.markdown("---")

# Section 3: Capstone Evaluation Summary Report
st.subheader("3. Downloadable Capstone Evaluation Report")

report_text = f"""# Capstone Evaluation Summary: Electricity Load Forecasting System
Methodology: PSF + SOM + ANN + GA Optimization
Dataset: {DATASET_NAME}

## Base Research Paper
Title: {BASE_RESEARCH_PAPER['title']}
Authors: {BASE_RESEARCH_PAPER['authors']}
Journal: {BASE_RESEARCH_PAPER['journal']} ({BASE_RESEARCH_PAPER['year']})
DOI: {BASE_RESEARCH_PAPER['doi']}

## Dataset Specification
- Dataset: {DATASET_NAME}
- Selected Consumers: 240 meters (30 meters from each of 8 categories, random_state=42)
- Total Calendar Days: 366 (2024 leap year)
- Total Daily Profiles: 87,840 (240 consumers × 366 days)
- Sampling Resolution: 15 minutes (96 intervals per day)
- Chronological Split: First 256 days (Train: 61,440 profiles) / Last 110 days (Test: 26,400 profiles)
- Test Evaluation Size: 26,400 daily forecasts (240 consumers × 110 test days × 96 readings/day)
- Evaluation Runtime: Baseline = {b_m.get('runtime_seconds', 19.56):.2f}s, GA = {g_m.get('runtime_seconds', 17.98):.2f}s

## GA Selected Configuration
- Hidden Neurons: {VALIDATED_FLUVIUS_RESULTS['ga']['selected_hidden_neurons']}
- Learning Rate: {VALIDATED_FLUVIUS_RESULTS['ga']['selected_learning_rate']:.6f}
- Validation RMSE: {VALIDATED_FLUVIUS_RESULTS['ga']['val_rmse']:.4f} {LOAD_UNIT}

## Experimental Performance Metrics (26,400 Forecasts)
- Baseline PSF + SOM + ANN:
  * MAE: {b_m['mae']:.4f} {LOAD_UNIT}
  * RMSE: {b_m['rmse']:.4f} {LOAD_UNIT}
  * MAPE: {b_m['mape']:.2f}%
  * Test Evaluation Runtime: {b_m.get('runtime_seconds', 19.56):.2f} s

- GA-Optimized Model:
  * MAE: {g_m['mae']:.4f} {LOAD_UNIT}
  * RMSE: {g_m['rmse']:.4f} {LOAD_UNIT}
  * MAPE: {g_m['mape']:.2f}%
  * Test Evaluation Runtime: {g_m.get('runtime_seconds', 17.98):.2f} s

## Conclusion
{VALIDATED_FLUVIUS_RESULTS['conclusion']}
"""

st.download_button(
    "📥 Download Official Capstone Evaluation Report (Markdown)",
    data=report_text.encode("utf-8"),
    file_name="capstone_fluvius_evaluation_report.md",
    mime="text/markdown",
    use_container_width=True
)
