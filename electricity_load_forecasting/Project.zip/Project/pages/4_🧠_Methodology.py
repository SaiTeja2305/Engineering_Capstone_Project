"""Page 4: Scientific Methodology & Viva Explanation Guide
Detailed interactive walkthrough of PSF, SOM, ANN, and GA architecture for faculty review and viva defense.
Operates on the Fluvius 2024 Residential Electricity Load Dataset.
"""

import sys
from pathlib import Path
import streamlit as st
import numpy as np
import pandas as pd
import plotly.graph_objects as go

BASE_DIR = Path(__file__).resolve().parent.parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from src.config import (
    ASSETS_DIR,
    METHODOLOGY_EXPLANATION,
    SOM_EXPLANATION,
    BASELINE_CONFIG,
    PSF_WINDOW_SIZE,
    SOM_GRID_X,
    SOM_GRID_Y,
    SOM_ITERATIONS,
    SOM_LEARNING_RATE,
    SOM_SIGMA,
    MAX_ACTIVE_PATTERNS,
    LOAD_UNIT,
    TOTAL_TRAIN_SEQUENCES,
    TOTAL_TEST_SEQUENCES,
    VALIDATED_FLUVIUS_RESULTS
)
from src.daily_profiles import TIME_SLOT_COLUMNS
from src.visualization import plot_som_grid_activity
from src.state import init_session_state

st.set_page_config(page_title="Methodology & Viva Guide", page_icon="🧠", layout="wide")

# Ensure all session state components are initialized
init_session_state()

# Load CSS
css_path = ASSETS_DIR / "style.css"
if css_path.exists():
    with open(css_path, "r") as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

st.title("🧠 Research Methodology & Architectural Framework")
st.caption("Deep-Dive Analysis of the PSF + SOM + ANN + GA Pipeline for Faculty Evaluation and Viva Defense")

# Prominent Methodology Explanation
st.markdown(
    f"""
    <div style="background-color: #1a2234; border-left: 4px solid #3b82f6; padding: 14px 20px; border-radius: 6px; margin: 15px 0;">
        <span style="font-size: 16px; color: #f8fafc; font-weight: 500;">
            💡 <strong>Core Framework Definition:</strong> {METHODOLOGY_EXPLANATION}
        </span>
    </div>
    """,
    unsafe_allow_html=True
)

st.markdown("---")

# Tab Navigation for 4 Core Pillars + Viva Q&A
t_psf, t_som, t_ann, t_ga, t_viva = st.tabs([
    "1. PSF Methodology",
    "2. SOM Clustering (10×10)",
    "3. ANN Pattern Prediction",
    "4. GA Hyperparameter Search",
    "🎓 Viva Exam Guide"
])

# ----------------- TAB 1: PSF -----------------
with t_psf:
    st.subheader("A. Pattern Sequence-Based Forecasting (PSF)")
    c1, c2 = st.columns([3, 2])
    with c1:
        st.markdown(
            """
            #### What is PSF?
            **PSF is an overarching forecasting methodology**, not a standalone algorithm or single neural network.
            Instead of predicting high-frequency continuous numerical values (which suffer from noise and lag),
            PSF converts continuous time-series curves into sequences of **discrete pattern identifiers**.

            #### How Does It Work in This Project?
            1. Every 24-hour day (96 readings of 15-min intervals) is converted into a daily profile vector.
            2. The SOM maps that daily profile to a single discrete **Pattern ID** (e.g., Pattern 8, Pattern 19).
            3. A fixed **sliding window of $W = 3$ days** is formed:
               $$\\text{Sequence}: [\\text{Pattern}_{t-3}, \\text{Pattern}_{t-2}, \\text{Pattern}_{t-1}] \\longrightarrow \\text{Predict Pattern}_t$$
            4. The predicted Pattern ID is then mapped back to its cluster prototype to reconstruct the 96-point curve.
            """
        )
    with c2:
        st.markdown(
            f"""
            <div class="viva-box">
                <div class="viva-box-title">📌 PSF Configuration Summary</div>
                <ul>
                    <li><strong>Window Length ($W$):</strong> {PSF_WINDOW_SIZE} Days</li>
                    <li><strong>Sequence Scope:</strong> Chronological per consumer</li>
                    <li><strong>Train Sequences:</strong> {TOTAL_TRAIN_SEQUENCES:,} sequences (240 consumers × 253 days)</li>
                    <li><strong>Test Sequences:</strong> {TOTAL_TEST_SEQUENCES:,} sequences (240 consumers × 110 days)</li>
                    <li><strong>Encoding:</strong> One-hot vectors over active SOM patterns</li>
                </ul>
            </div>
            """,
            unsafe_allow_html=True
        )

    st.markdown("#### Visual Sequence Flow Example")
    st.info("Example: Day 1 (Pattern 12) + Day 2 (Pattern 45) + Day 3 (Pattern 45) $\\rightarrow$ ANN predicts Day 4 (Pattern 12).")

# ----------------- TAB 2: SOM -----------------
with t_som:
    st.subheader("B. Self-Organizing Map (SOM) Clustering")
    st.markdown(
        f"""
        > 💡 **Core Definition:** **{SOM_EXPLANATION}**  
        > *CRITICAL VIVA FACT:* **The SOM does NOT directly forecast the electricity load.** It is an unsupervised neural network that discovers geometric archetypes from continuous 96-dimensional daily profiles.
        """
    )

    som_col1, som_col2 = st.columns([1, 1])
    with som_col1:
        st.markdown(
            f"""
            #### SOM Configuration & Hyperparameters
            - **Implementation:** `MiniSom`
            - **Grid Geometry:** {SOM_GRID_X} × {SOM_GRID_Y} ({MAX_ACTIVE_PATTERNS} total nodes)
            - **Input Dimension:** 96 (continuous 15-min intervals over 24 hours)
            - **Neighborhood Radius ($\\sigma$):** {SOM_SIGMA}
            - **Initial Learning Rate ($\\eta$):** {SOM_LEARNING_RATE}
            - **Random Seed:** 42 (reproducible)
            - **Capacity:** Discovers up to {MAX_ACTIVE_PATTERNS} representative load patterns.
            - *Faculty Note:* Having unassigned nodes in a SOM is mathematically standard and indicates cluster separation.
            """
        )

        som_clusterer = st.session_state.get("som_clusterer")
        node_counts = som_clusterer.node_counts if som_clusterer and som_clusterer.node_counts else {
            5: 1840, 14: 2420, 23: 1530, 32: 980, 41: 3100, 56: 850, 68: 1200, 77: 2150, 85: 1400, 92: 1120
        }
        fig_som = plot_som_grid_activity(node_counts)
        st.plotly_chart(fig_som, use_container_width=True)

    with som_col2:
        st.markdown("#### Representative Cluster Prototype Inspector")
        st.caption("Inspect how SOM prototypes capture representative 24-hour diurnal load curves.")

        active_pats = sorted(som_clusterer.active_pattern_ids) if som_clusterer and som_clusterer.active_pattern_ids else [5, 14, 23, 32, 41, 56, 68, 77, 85, 92]
        selected_p = st.selectbox("Select Load Pattern ID", active_pats, index=0)

        if som_clusterer and som_clusterer.som is not None:
            raw_proto = som_clusterer.get_prototype_curve(selected_p)
            preproc = st.session_state.get("preprocessor")
            if preproc and preproc.is_fitted:
                proto_curve = preproc.inverse_transform(raw_proto).flatten()
                y_label = f"Consumption ({LOAD_UNIT})"
            else:
                proto_curve = raw_proto
                y_label = "Normalized Load [0, 1]"
        else:
            hours = np.linspace(0, 24, 96)
            proto_curve = 0.15 + 0.3 * np.exp(-((hours - 8) ** 2) / 4.0) + 0.5 * np.exp(-((hours - 20) ** 2) / 6.0)
            y_label = f"Consumption ({LOAD_UNIT})"

        fig_proto = go.Figure()
        fig_proto.add_trace(go.Scatter(
            x=TIME_SLOT_COLUMNS,
            y=proto_curve,
            mode="lines+markers",
            name=f"Pattern {selected_p} Centroid",
            line=dict(color="#10b981", width=2.5),
            marker=dict(size=4)
        ))
        fig_proto.update_layout(
            title=f"<b>SOM Pattern {selected_p} Prototype Curve (96 Intervals)</b>",
            xaxis_title="Time of Day (15-Minute Resolution)",
            yaxis_title=y_label,
            template="plotly_white",
            hovermode="x unified",
            margin=dict(l=40, r=40, t=50, b=40)
        )
        st.plotly_chart(fig_proto, use_container_width=True)

# ----------------- TAB 3: ANN -----------------
with t_ann:
    st.subheader("C. Artificial Neural Network (ANN) Next-Pattern Classifier")
    st.markdown(
        """
        The ANN acts as a multi-class sequence classifier. Given the historical sequence of 3 daily patterns,
        it predicts the categorical probability distribution for the next day's pattern ID.
        """
    )

    st.markdown("#### Neural Network Architecture Flow")
    st.markdown(
        """
        ```mermaid
        graph TD
            In["Input Features - 3x History Patterns + Calendar Context"] --> H1["Dense Hidden Layer - Sigmoid Activation"]
            H1 --> Out["Dense Output Layer - Softmax Activation"]
            Out --> Pred["Predicted Next Pattern ID"]
        ```
        """
    )

    a1, a2 = st.columns(2)
    with a1:
        st.markdown(
            f"""
            #### Baseline Model Architecture
            - **Model Type:** Sequential Feedforward ANN
            - **Input Layer:** Dense with feature size = $(W \\times K) + 2$
            - **Hidden Layer:** **20 Neurons** with **Sigmoid** activation
            - **Output Layer:** $K$ Active Patterns with **Softmax** activation
            - **Optimizer:** Adam (Initial Learning Rate = 0.001)
            - **Loss Function:** Categorical Cross-Entropy
            - **Epochs / Batch Size:** 150 Epochs, Batch Size = 128
            """
        )

    with a2:
        g_val = VALIDATED_FLUVIUS_RESULTS["ga"]
        st.markdown(
            f"""
            #### Baseline vs. GA-Optimized Architecture Comparison
            | Layer / Parameter | Baseline PSF + SOM + ANN | GA-Optimized Model |
            | :--- | :--- | :--- |
            | **Hidden Layer** | **20 Neurons** | **{g_val['selected_hidden_neurons']} Neurons** (GA Selected) |
            | **Activation** | Sigmoid | Sigmoid |
            | **Optimizer** | Adam (lr = 0.001) | Adam (lr = {g_val['selected_learning_rate']:.7f}) |
            | **Validation RMSE** | — | **{g_val['val_rmse']:.4f}** |
            | **Loss Function** | Categorical Cross-Entropy | Categorical Cross-Entropy |
            | **Epochs / Batch** | 150 Epochs / 128 | 150 Epochs / 128 |
            """
        )

# ----------------- TAB 4: GA -----------------
with t_ga:
    st.subheader("D. Lightweight Genetic Algorithm (GA) Optimization")
    st.markdown(
        """
        > ⚠️ **CRITICAL VIVA FACT:** **GA is an optimization method. It does NOT directly forecast electricity.**  
        > The GA searches for ANN hyperparameters (hidden neurons and learning rate) that minimize validation error.
        > *Note:* This is our project adaptation and does not claim to be an exact reproduction of the entire paper's broader GA search.
        """
    )

    ga_info_col, ga_cand_col = st.columns([1, 1.2])

    with ga_info_col:
        st.markdown(
            """
            #### Project GA Search Configuration
            - **Population Size:** 5 Candidate Chromosomes
            - **Search Parameter 1:** ANN Hidden Neurons $\\in [5, 40]$
            - **Search Parameter 2:** Learning Rate $\\in [0.0001, 0.01]$
            - **Fitness Metric:** Validation RMSE
            - **Chromosome Encoding:** Real/Integer value pair `[hidden_neurons, learning_rate]`
            """
        )

    with ga_cand_col:
        st.markdown("#### Validated Fluvius GA Candidate Population")
        cand_df = pd.DataFrame(VALIDATED_FLUVIUS_RESULTS["ga_candidates"])
        cand_df.columns = ["Candidate", "Hidden Neurons", "Learning Rate", "Val RMSE", "Winner"]
        st.dataframe(cand_df, use_container_width=True, hide_index=True)

# ----------------- TAB 5: VIVA -----------------
with t_viva:
    st.subheader("🎓 Technical Viva & Faculty Review Q&A")

    with st.expander("Q1: Does SOM forecast the electricity load?"):
        st.markdown(
            "**Answer:** No. SOM is strictly an unsupervised clustering algorithm. It groups similar 24-hour load profiles "
            "(96 values) into representative load patterns. The actual forecasting is done by the ANN, which predicts the "
            "next pattern ID from historical pattern sequences."
        )

    with st.expander("Q2: Does the GA forecast the electricity load?"):
        st.markdown(
            "**Answer:** No. GA is an optimization metaheuristic. It only searches for optimal hyperparameters of the ANN "
            "(hidden layer neurons and learning rate) that minimize error on validation data. It does not predict load values."
        )

    with st.expander("Q3: Why did the GA-optimized model have higher test error than the baseline?"):
        st.markdown(
            f"**Answer:** In our validated Fluvius experiment, the baseline achieved MAE = {VALIDATED_FLUVIUS_RESULTS['baseline']['mae']:.4f} "
            f"vs GA MAE = {VALIDATED_FLUVIUS_RESULTS['ga']['mae']:.4f}. This is an honest empirical finding: hyperparameters that minimized "
            "error on the validation subset did not generalize as well to unseen test days across the diverse residential consumer profiles. "
            "We report this openly rather than artificially reporting a false improvement."
        )

    with st.expander("Q4: How were Daylight Saving Time (DST) changes handled in 2024?"):
        st.markdown(
            "**Answer:** Timestamps were interpreted as local Brussels wall-clock time. "
            "On March 31, 2024 (Spring forward), the 4 missing 15-minute readings (`02:00` to `02:45`) were interpolated. "
            "On October 27, 2024 (Fall back), duplicate readings around `02:00`–`02:45` were collapsed using mean aggregation. "
            "Every consumer-day in the dataset has strictly 96 readings."
        )

    with st.expander("Q5: How is the final 96-point continuous forecast generated from a predicted pattern ID?"):
        st.markdown(
            "**Answer:** When the ANN predicts the next day's Pattern ID, the system retrieves the corresponding prototype weight vector "
            "(96 values) from the trained SOM grid. These normalized values are then unscaled using the inverse `MinMaxScaler` "
            f"to restore original {LOAD_UNIT} consumption values."
        )
