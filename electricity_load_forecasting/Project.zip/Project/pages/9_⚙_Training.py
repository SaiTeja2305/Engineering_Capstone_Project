"""Page 9: Model Training, Retraining & Persistence
Structured training pipeline for SOM, PSF Sequences, Baseline ANN, and GA-Optimized Model.
Operates on the Fluvius 2024 Residential Electricity Load Dataset.
"""

import sys
import time
from pathlib import Path
import pandas as pd
import streamlit as st
import numpy as np

BASE_DIR = Path(__file__).resolve().parent.parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from src.config import (
    ASSETS_DIR,
    MODELS_DIR,
    SOM_GRID_X,
    SOM_GRID_Y,
    SOM_ITERATIONS,
    SOM_SUBSAMPLE_STEP,
    VALIDATED_FLUVIUS_RESULTS,
    TRAIN_DAYS
)
from src.psf_model import build_psf_sequences
from src.fluvius_loader import generate_fluvius_demo_profiles
from src.daily_profiles import split_daily_profiles_chronologically
from src.state import init_session_state

st.set_page_config(page_title="Model Training & Persistence", page_icon="⚙️", layout="wide")

# Ensure all session state components are initialized
init_session_state()

# Load CSS
css_path = ASSETS_DIR / "style.css"
if css_path.exists():
    with open(css_path, "r") as f:
        st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

st.title("⚙️ Model Training & Persistence Pipeline")
st.caption("Execute structured training stages, train SOM prototypes, fit ANN models, and inspect checkpoints")

st.markdown("---")

# Section 1: Structured Training Stages Checklist (Section 25 Requirements)
st.subheader("1. Training Pipeline Stages Checklist")

has_profiles = st.session_state.get("daily_profiles_df") is not None
has_split = st.session_state.get("train_df") is not None
has_som = getattr(st.session_state.get("som_clusterer"), "is_trained", False)
has_base_ann = getattr(st.session_state.get("baseline_ann"), "is_trained", False)
has_ga_ann = getattr(st.session_state.get("ga_ann"), "is_trained", False)
has_eval = st.session_state.get("dynamic_results") is not None

col_s1, col_s2, col_s3, col_s4 = st.columns(4)
with col_s1:
    st.markdown(f"{'✅' if has_profiles else '⏳'} **1. Dataset Preparation**")
    st.markdown(f"{'✅' if has_som else '⏳'} **2. SOM Training**")
with col_s2:
    st.markdown(f"{'✅' if has_som else '⏳'} **3. PSF Sequence Generation**")
    st.markdown(f"{'✅' if has_base_ann else '⏳'} **4. Baseline ANN Training**")
with col_s3:
    st.markdown(f"{'✅' if has_ga_ann else '⏳'} **5. GA Optimization**")
    st.markdown(f"{'✅' if has_ga_ann else '⏳'} **6. GA ANN Training**")
with col_s4:
    st.markdown(f"{'✅' if has_eval else '⏳'} **7. Model Evaluation**")

st.markdown("---")

if st.session_state.get("train_df") is None:
    st.warning("⚠️ No training profiles found. Please upload Fluvius archives or load demo profiles.")
    if st.button("🚀 Load Fluvius Demo Profiles"):
        demo_df = generate_fluvius_demo_profiles(consumers_per_category=1, days=366)
        st.session_state.daily_profiles_df = demo_df
        train_df, test_df = split_daily_profiles_chronologically(demo_df, train_days_per_customer=TRAIN_DAYS)
        st.session_state.train_df = train_df
        st.session_state.test_df = test_df
        st.session_state.preprocessor.fit_transform_train(train_df)
        st.rerun()
    st.stop()

train_df = st.session_state.train_df

# Section 2: Interactive Model Training Controls
st.subheader("2. Interactive Training Controls")
col_train1, col_train2 = st.columns(2)

with col_train1:
    st.markdown("#### Self-Organizing Map (SOM)")
    st.markdown(f"**Grid:** {SOM_GRID_X}×{SOM_GRID_Y} (100 nodes) | **Input:** 96 intervals | **Seed:** 42")

    som_iter = st.number_input("SOM Iterations", min_value=100, max_value=10000, value=500, step=250)
    if st.button("🔄 Train / Retrain SOM", type="primary", use_container_width=True):
        progress_bar = st.progress(0)
        status_text = st.empty()
        status_text.text("Normalizing training profiles with MinMaxScaler...")

        train_scaled, stats = st.session_state.preprocessor.fit_transform_train(train_df)
        progress_bar.progress(30)
        status_text.text(f"Training MiniSom ({som_iter} iterations)...")

        t0 = time.time()
        som_res = st.session_state.som_clusterer.train(train_scaled, subsample_step=1, num_iterations=som_iter)
        elapsed = time.time() - t0

        progress_bar.progress(100)
        status_text.text("SOM Training Completed!")

        st.success(
            f"✅ SOM Trained in {elapsed:.2f}s! Discovered {som_res['active_pattern_count']} active load pattern clusters."
        )
        st.session_state.som_clusterer.save()

with col_train2:
    st.markdown("#### Artificial Neural Network (ANN)")
    g_info = VALIDATED_FLUVIUS_RESULTS["ga"]
    model_to_train = st.radio(
        "Select Model Architecture to Fit:",
        [
            "Baseline ANN (20 Neurons, lr=0.001)",
            f"GA-Optimized ANN ({g_info['selected_hidden_neurons']} Neurons, lr={g_info['selected_learning_rate']:.7f})"
        ]
    )
    epochs_input = st.number_input("Training Epochs", min_value=1, max_value=200, value=20, step=10)

    if st.button("🚀 Train Selected ANN Model", use_container_width=True):
        if not st.session_state.som_clusterer.active_pattern_ids:
            st.error("Please train the SOM first before training the ANN!")
        else:
            with st.spinner("Extracting PSF sequences and training ANN..."):
                train_scaled = st.session_state.preprocessor.scaler.transform(train_df[st.session_state.preprocessor.feature_names].values)
                pattern_ids = st.session_state.som_clusterer.map_profiles_to_patterns(train_scaled)

                X, y, meta = build_psf_sequences(
                    daily_profiles_df=train_df,
                    pattern_ids=pattern_ids,
                    pattern_to_class_idx=st.session_state.som_clusterer.pattern_to_class_idx
                )

                if len(X) == 0:
                    st.error("Insufficient sequence length for sliding window of 3. Check dataset.")
                else:
                    t0 = time.time()
                    if "Baseline" in model_to_train:
                        ann = st.session_state.baseline_ann
                    else:
                        ann = st.session_state.ga_ann

                    history = ann.train(X, y, epochs=epochs_input, batch_size=128, verbose=0)
                    elapsed = time.time() - t0
                    ann.save()

                    st.success(f"✅ ANN Model Trained in {elapsed:.2f}s across {len(X):,} sequences!")
                    st.session_state["last_ann_history"] = history

# Advanced Debug Logs expander (Hidden by default per Section 25)
with st.expander("🛠️ Advanced / Debug Logs", expanded=False):
    som_clusterer = st.session_state.get("som_clusterer")
    active_patterns = len(som_clusterer.active_pattern_ids) if som_clusterer and hasattr(som_clusterer, "active_pattern_ids") else 0
    st.write({
        "preprocessor_fitted": getattr(st.session_state.get("preprocessor"), "is_fitted", False),
        "som_trained": getattr(som_clusterer, "is_trained", False),
        "active_som_patterns": active_patterns,
        "baseline_ann_trained": getattr(st.session_state.get("baseline_ann"), "is_trained", False),
        "ga_ann_trained": getattr(st.session_state.get("ga_ann"), "is_trained", False)
    })

    if "last_ann_history" in st.session_state:
        last_hist = st.session_state["last_ann_history"]
        losses = last_hist.get("loss", []) if isinstance(last_hist, dict) else getattr(last_hist, "history", {}).get("loss", [])
        if losses:
            st.write("Recent Epoch Training Losses:", [round(float(l), 5) for l in losses[-5:]])

st.markdown("---")

# Section 3: Checkpoints & Disk Status
st.subheader("3. Model Checkpoint & Persistence Status")
p_files = [f for f in MODELS_DIR.glob("*") if f.is_file() and not f.name.startswith(".")] if MODELS_DIR.exists() else []

if p_files:
    f_data = [
        {
            "Filename": f.name,
            "Size (KB)": f"{f.stat().st_size / 1024:.2f}",
            "Modified": time.ctime(f.stat().st_mtime)
        }
        for f in p_files
    ]
    st.dataframe(pd.DataFrame(f_data), use_container_width=True, hide_index=True)
else:
    st.info("No checkpointed model files yet. Click buttons above to train and persist models.")
