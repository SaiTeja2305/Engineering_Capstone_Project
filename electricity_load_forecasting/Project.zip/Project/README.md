# Electricity Load Forecasting System (PSF-SOM-ANN-GA)

> **Final-Year Engineering Capstone Project**  
> **Specialization:** Data Science and Big Data Analytics, Computer Science & Engineering  
> **Base Research Paper:** *"An Improved Pattern Sequence-Based Energy Load Forecast Algorithm Based on Self-Organizing Maps and Artificial Neural Networks"*  
> **Authors:** D. Criado-Ramón, L. G. B. Ruiz, M. C. Pegalajar (*Big Data and Cognitive Computing*, 2023, DOI: [10.3390/bdcc7020092](https://doi.org/10.3390/bdcc7020092))

---

## 1. Project Overview & Problem Statement

Electricity consumption fluctuates dynamically across seasons, days of the week, and hours of the day, exhibiting strong recurring daily patterns. Accurate short-term load forecasting is vital for grid reliability, peak load management, demand response scheduling, and energy trading.

Traditional time-series forecasting algorithms (ARIMA, standard RNNs) often struggle to isolate distinct multi-day pattern sequences directly from raw, noisy 15-minute readings. This project implements an interactive, explainable, web-based adaptation of the **PSF + SOM + ANN + GA** paradigm:

1. **PSF (Pattern Sequence-Based Forecasting):** The high-level forecasting methodology that transforms continuous time-series load curves into sequences of discrete daily pattern identifiers.
2. **SOM (Self-Organizing Map):** An unsupervised 2D grid (10×10) clustering mechanism that groups 96-dimensional daily electricity profiles into representative pattern centroids (53 active pattern IDs).
3. **ANN (Artificial Neural Network):** A supervised classifier predicting the *next day's pattern ID* based on a sequence of the previous 3 days' pattern IDs plus calendar attributes (day of week, month).
4. **GA (Genetic Algorithm):** An evolutionary optimization procedure searching for optimal ANN hyperparameters (hidden neurons and learning rate) against validation RMSE.

---

## 2. Important Scientific Distinctions & Viva Guidance

| Concept | What It Is | What It Does In This Project | What It Is NOT |
| :--- | :--- | :--- | :--- |
| **PSF** | Forecasting Methodology | Represents daily profiles as pattern sequences to predict the next pattern | Not a standalone neural network |
| **SOM** | Unsupervised Clustering | Groups 96-point daily profiles into Best Matching Units (BMUs) / pattern IDs | **Does NOT directly forecast electricity load** |
| **ANN** | Multi-class Classifier | Predicts the next pattern ID given prior sequence and calendar context | Not directly outputting 96 raw continuous numbers |
| **GA** | Metaheuristic Optimizer | Searches for suitable ANN hyperparameter configurations (neurons, lr) | **Does NOT directly forecast electricity load** |

### Research Paper vs. Our Implementation
- **Original Paper Datasets:** REE (Spain), AEMO (Australia), and NYISO (USA).
- **Our Project Dataset:** Fluvius 2024 Residential Electricity Load Dataset (240 selected consumers across 8 categories, 366 days in 2024: 240 customers × 366 days = 87,840 daily profiles).
- **Paper GA:** Explores SOM dimensions, PSF window length, and ANN hyperparameters.
- **Our GA:** A real lightweight GA search fixing SOM (10×10 grid = 100 pattern space) and PSF window ($W=3$), dynamically evaluating candidates over hidden neurons ($5–40$) and learning rate ($0.0001–0.01$) against computed Validation RMSE.

---

## 3. Dataset Characteristics

- **Source:** Fluvius 2024 Belgian Residential Smart Meter Dataset
- **Year Analyzed:** 2024 (366 leap-year calendar days, Jan 1 to Dec 31)
- **Consumers Selected:** 240 consumers (30 per category across 8 categories: Standard, Heat Pump, EV, Solar/PV, etc.)
- **Sampling Interval:** 15 minutes $\rightarrow 96$ readings per customer per day
- **Total Daily Profiles:** $240 \times 366 = 87,840$ daily profiles
- **Train/Test Partition:** Chronological split (First 256 days $\approx 70\%$ train, Last 110 days $\approx 30\%$ test)
- **Test Set Evaluation Size:** $240 \text{ consumers} \times 110 \text{ test days} = 26,400$ daily 96-point forecasts.
- **Normalization:** `MinMaxScaler` fitted **strictly on training profiles** to prevent data leakage.
- **Architecture Dimensions:** SOM grid 10×10 = 100 pattern space, PSF input dimension $(3 \times 100) + 2 = 302$ features, ANN output dimension 100 pattern classes.

---

## 4. System Architecture & Directory Layout

```
project_root/
│
├── app.py                     # Streamlit main entrypoint & navigation
│
├── pages/                     # Multipage interactive modules
│   ├── 1_📊_Dashboard.py        # Executive summary, pipeline flow, KPI cards
│   ├── 2_📁_Dataset.py          # Upload (Fluvius Part 1 & Part 2 CSVs), validation
│   ├── 3_🔍_Data_Exploration.py # Interactive 24-hr & historical load curves (Plotly)
│   ├── 4_🧠_Methodology.py      # Detailed educational viva guide (PSF, SOM, ANN, GA)
│   ├── 5_📈_Forecasting.py      # 96-point day-ahead forecast generation vs ground truth
│   ├── 6_🧬_GA_Optimization.py # Dynamic GA candidate evaluation & validation RMSE
│   ├── 7_⚖️_Model_Comparison.py # Full batch test set evaluation & side-by-side metrics
│   ├── 8_📋_Results.py          # Current live experiment vs historical reference results
│   └── 9_⚙️_Training.py         # End-to-end multi-model retraining & checkpoint persistence
│
├── src/                       # Modular business & scientific logic
│   ├── config.py              # Central constants, category mapping, baseline & GA bounds
│   ├── fluvius_loader.py      # Multi-part CSV loader, local wall-clock DST parser, demo generator
│   ├── preprocessing.py       # Cleaning, integrity checks, MinMaxScaler fit/transform
│   ├── daily_profiles.py      # 15-min time-series to 96-column daily matrix transformation
│   ├── som_model.py           # 10x10 grid clustering, 100-node pattern mapping, prototype curves
│   ├── psf_model.py           # Window-3 100-class sequence encoding (302 features)
│   ├── ann_model.py           # Keras/TF model architectures (302 input -> 100 output)
│   ├── ga_optimizer.py        # Real 5-candidate GA hyperparameter search on validation split
│   ├── forecasting.py         # Full day-ahead inference engine & batch test set evaluation
│   ├── evaluation.py          # MAE, RMSE, MAPE (with 1e-3 epsilon protection)
│   └── visualization.py       # Reusable, responsive Plotly interactive charts
│
├── models/                    # Serialized models, scalers, and SOM weights
├── data/                      # Input raw and processed datasets
├── outputs/                   # Exported forecast CSVs and evaluation reports
├── assets/                    # Custom CSS styling and diagrams
├── requirements.txt           # Python dependency specification
└── README.md                  # Project documentation
```

---

## 5. Installation and Execution

### Step 1: Clone or Navigate to Directory
```bash
cd "d:\B. Tech\7th Sem(4-1)\Engineering CapStone Project\Project"
```

### Step 2: Install Dependencies
```bash
pip install -r requirements.txt
```

### Step 3: Launch Web Application
```bash
streamlit run app.py
```
The browser will automatically open at `http://localhost:8501`.

---

## 6. Walkthrough of Web Application Pages

1. **Dashboard:** High-level project summary, dataset specs, methodology flow chart, and quick links.
2. **Dataset:** Upload raw UCI files (supports original comma/semicolon format), view automatic schema validation, sampling interval detection, and dataset stats. Also features an instant *Sample Dataset Loader* for immediate demonstration without a large file.
3. **Data Exploration:** Select any customer (MT_001 to MT_250) and date to inspect 96-point load curves, peak demand, minimum consumption, and monthly trends.
4. **Methodology:** Interactive technical explanation of PSF, SOM, ANN, and GA designed specifically for faculty evaluation and viva questions.
5. **Forecasting:** Select customer, date, and model (Baseline vs. GA-Optimized). Generates an interactive Plotly comparison of Actual vs. Predicted load, with real-time MAE, RMSE, and MAPE calculations. Allows CSV export.
6. **GA Optimization:** Visualizes the 5 candidate configurations, showing hidden neurons, learning rates, and validation RMSE, highlighting Candidate 2 ($N=33, \text{lr} \approx 0.00593$).
7. **Model Comparison:** Direct side-by-side comparison tables, bar charts, and computational execution time measurements.
8. **Results & Evaluation:** Capstone summary, viva explanation of why GA did not exceed baseline accuracy, and context regarding original research paper metrics.
9. **Training & Persistence:** Retrain SOM, baseline ANN, or GA-optimized model on demand with live progress reporting.

---

## 7. Faculty Viva Questions & Answers

**Q1: Does SOM forecast the load?**  
*Answer:* No. SOM is strictly an unsupervised clustering algorithm. It maps 96-dimensional daily profiles to 2D nodes (pattern IDs). The forecasting is performed by the ANN, which predicts the next pattern ID based on prior sequences.

**Q2: What is the input dimension to the ANN?**  
*Answer:* 161 features. With a PSF window of 3 days and 53 active pattern classes, one-hot encoding yields $3 \times 53 = 159$ features, plus 2 calendar features (day-of-week and month).

**Q3: Why didn't the GA model beat the baseline?**  
*Answer:* The GA optimized hyperparameters on a small validation subset (5 customers over 255 days) to keep computation feasible. In a highly heterogeneous dataset of 250 customers, hyperparameters tuned to a 5-customer subset may slightly overfit or fail to generalize across all meter behaviors. This demonstrates the critical nuance of generalizability in big-data load forecasting.

**Q4: How was data leakage prevented?**  
*Answer:* `MinMaxScaler` was fitted solely on the first 255 training days. The test set (last 110 days) was transformed using the training scaler parameters without recalculating minimum or maximum bounds.
