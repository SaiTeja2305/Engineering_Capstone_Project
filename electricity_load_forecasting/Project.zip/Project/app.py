"""Electricity Load Forecasting System
Main Streamlit Application Entrypoint & Executive Dashboard
PSF + SOM + ANN + GA Optimization (Fluvius 2024 Residential Dataset)
"""

import sys
from pathlib import Path
import streamlit as st
import pandas as pd
import numpy as np

# Add project root to sys.path
BASE_DIR = Path(__file__).resolve().parent
if str(BASE_DIR) not in sys.path:
    sys.path.insert(0, str(BASE_DIR))

from src.config import (
    BASE_RESEARCH_PAPER,
    DATASET_NAME,
    DATASET_YEAR,
    PROJECT_TITLE,
    FULL_PROJECT_TITLE,
    METHODOLOGY_EXPLANATION,
    SOM_EXPLANATION,
    READINGS_PER_DAY,
    SOM_GRID_X,
    SOM_GRID_Y,
    MAX_ACTIVE_PATTERNS,
    TOTAL_DAILY_PROFILES,
    TOTAL_DAYS,
    SELECTED_CONSUMERS_DEFAULT,
    TOTAL_AVAILABLE_CONSUMERS,
    NUM_CATEGORIES,
    ASSETS_DIR,
    VALIDATED_FLUVIUS_RESULTS,
    RANDOM_STATE
)
from src.fluvius_loader import generate_fluvius_demo_profiles
from src.daily_profiles import split_daily_profiles_chronologically
from src.state import init_session_state
from src.forecasting import LoadForecaster

# Set Streamlit Page Configuration
st.set_page_config(
    page_title=f"{PROJECT_TITLE} | Capstone Project",
    page_icon="⚡",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Load CSS Styles
def load_custom_css():
    css_path = ASSETS_DIR / "style.css"
    if css_path.exists():
        with open(css_path, "r") as f:
            st.markdown(f"<style>{f.read()}</style>", unsafe_allow_html=True)

load_custom_css()

# Session State Initialization
init_session_state()

# Sidebar Information
with st.sidebar:
    st.title("⚡ Load Forecast System")
    st.caption("Engineering Capstone Project (PR2 / Viva)")

    st.markdown("---")
    st.markdown("### 🎓 Academic Context")
    st.markdown(
        "**Student:** Final-Year B.Tech CSE  \n"
        "**Specialization:** Data Science & Big Data  \n"
        "**Methodology:** PSF + SOM + ANN + GA  \n"
        "**Dataset:** Fluvius 2024 Residential (Belgium)"
    )

    st.markdown("---")
    st.markdown("### 📄 Base Research Paper")
    st.caption(
        f"*{BASE_RESEARCH_PAPER['title']}*\n\n"
        f"**Authors:** {BASE_RESEARCH_PAPER['authors']}\n\n"
        f"**Journal:** {BASE_RESEARCH_PAPER['journal']} ({BASE_RESEARCH_PAPER['year']})\n\n"
        f"**DOI:** [{BASE_RESEARCH_PAPER['doi']}](https://doi.org/{BASE_RESEARCH_PAPER['doi']})\n\n"
        f"**Notes:** {BASE_RESEARCH_PAPER['notes']}"
    )

    st.markdown("---")
    st.info("💡 **Quick Demo:** Load realistic 2024 Fluvius profiles to immediately test all pages.")
    if st.button("🚀 Load Fluvius Demo Profiles", use_container_width=True):
        with st.spinner("Generating 2024 Fluvius daily profiles (8 categories, leap year 366 days)..."):
            demo_df = generate_fluvius_demo_profiles(consumers_per_category=1, days=366)
            st.session_state.daily_profiles_df = demo_df
            train_df, test_df = split_daily_profiles_chronologically(demo_df)
            st.session_state.train_df = train_df
            st.session_state.test_df = test_df

            train_scaled, _ = st.session_state.preprocessor.fit_transform_train(train_df)
            st.session_state.som_clusterer.train(train_scaled, subsample_step=1, num_iterations=400)
            st.session_state.forecaster = LoadForecaster(
                som_clusterer=st.session_state.som_clusterer,
                preprocessor=st.session_state.preprocessor,
                baseline_ann=st.session_state.baseline_ann,
                ga_ann=st.session_state.ga_ann
            )
            st.success("Fluvius profiles & SOM initialized! Ready for exploration & forecasting.")
            st.rerun()

# Main Dashboard View
st.markdown(
    f"""
    <div class="hero-banner">
        <div class="hero-title">{PROJECT_TITLE}</div>
        <div class="hero-subtitle">
            {FULL_PROJECT_TITLE}
        </div>
    </div>
    """,
    unsafe_allow_html=True
)

# Core Methodology Banner (Required UI explanation)
st.markdown(
    f"""
    <div style="background-color: #1a2234; border-left: 4px solid #3b82f6; padding: 12px 18px; border-radius: 6px; margin-bottom: 20px;">
        <span style="font-size: 15px; color: #e2e8f0; font-weight: 500;">
            💡 <strong>Methodology Summary:</strong> {METHODOLOGY_EXPLANATION}
        </span>
    </div>
    """,
    unsafe_allow_html=True
)

# KPI Metric Cards
col1, col2, col3, col4, col5 = st.columns(5)
with col1:
    st.markdown(
        f"""
        <div class="metric-card">
            <div class="metric-card-header">Dataset Scope</div>
            <div class="metric-card-value">{SELECTED_CONSUMERS_DEFAULT}</div>
            <div class="metric-card-sub">Meters (8 Categories × 30)</div>
        </div>
        """,
        unsafe_allow_html=True
    )
with col2:
    st.markdown(
        f"""
        <div class="metric-card">
            <div class="metric-card-header">Duration</div>
            <div class="metric-card-value">{TOTAL_DAYS}</div>
            <div class="metric-card-sub">Days (Calendar Year {DATASET_YEAR})</div>
        </div>
        """,
        unsafe_allow_html=True
    )
with col3:
    st.markdown(
        f"""
        <div class="metric-card">
            <div class="metric-card-header">Daily Profiles</div>
            <div class="metric-card-value">{TOTAL_DAILY_PROFILES:,}</div>
            <div class="metric-card-sub">240 Meters × 366 Days</div>
        </div>
        """,
        unsafe_allow_html=True
    )
with col4:
    st.markdown(
        f"""
        <div class="metric-card">
            <div class="metric-card-header">Sampling Rate</div>
            <div class="metric-card-value">{READINGS_PER_DAY}</div>
            <div class="metric-card-sub">Readings/Day (15-Min Intervals)</div>
        </div>
        """,
        unsafe_allow_html=True
    )
with col5:
    st.markdown(
        f"""
        <div class="metric-card">
            <div class="metric-card-header">SOM Clusters</div>
            <div class="metric-card-value">≤ {MAX_ACTIVE_PATTERNS}</div>
            <div class="metric-card-sub">Load Patterns ({SOM_GRID_X}×{SOM_GRID_Y} Grid)</div>
        </div>
        """,
        unsafe_allow_html=True
    )

# Section: Project Overview and Methodology Flow
st.markdown("### 🔄 End-to-End Forecasting Methodology Pipeline")
st.markdown(
    """
    This project transforms high-frequency continuous electricity consumption into discrete daily pattern sequences,
    using Self-Organizing Maps (SOM) for unsupervised clustering, Artificial Neural Networks (ANN) for sequence prediction,
    and a Genetic Algorithm (GA) for hyperparameter search.
    """
)

# Flow Diagram
st.markdown(
    """
    ```mermaid
    graph LR
        A["Historical Fluvius 15-min Readings"] --> B["Daily Load Profiles - 96 Readings"]
        B --> C["MinMaxScaler - Train-Only Fit"]
        C --> D["SOM 10x10 Grid Clustering"]
        D --> E["Daily Pattern Sequences - PSF Window 3"]
        E --> F["ANN Multi-Class Pattern Predictor"]
        G["Lightweight GA Hyperparameter Search"] -.- F
        F --> H["Predicted Next Pattern ID"]
        H --> I["SOM Centroid Reconstruction"]
        I --> J["Day-Ahead 96-Point Forecast Profile"]
        J --> K["Evaluation - MAE, RMSE, MAPE"]
    ```
    """
)

# Core Concepts Explanation Cards (Viva Focus)
st.markdown("### 🧠 Core Architectural Concepts")
c1, c2, c3, c4 = st.columns(4)

with c1:
    st.markdown(
        """
        <div class="pipeline-step">
            <h4>A. PSF</h4>
            <p><strong>Pattern Sequence-Based Forecasting</strong></p>
            <p>The overarching forecasting approach. Operates on chronological sequences of observed load patterns.</p>
        </div>
        """,
        unsafe_allow_html=True
    )

with c2:
    st.markdown(
        f"""
        <div class="pipeline-step">
            <h4>B. SOM</h4>
            <p><strong>Self-Organizing Map (10×10)</strong></p>
            <p>{SOM_EXPLANATION} <em>Does NOT directly forecast load.</em></p>
        </div>
        """,
        unsafe_allow_html=True
    )

with c3:
    st.markdown(
        """
        <div class="pipeline-step">
            <h4>C. ANN</h4>
            <p><strong>Artificial Neural Network</strong></p>
            <p>Receives the previous sequence of pattern IDs and predicts the next day's cluster pattern.</p>
        </div>
        """,
        unsafe_allow_html=True
    )

with c4:
    st.markdown(
        """
        <div class="pipeline-step">
            <h4>D. GA</h4>
            <p><strong>Genetic Algorithm</strong></p>
            <p>Optimizes ANN hidden neurons & learning rate. <em>An optimization method; does NOT directly forecast load.</em></p>
        </div>
        """,
        unsafe_allow_html=True
    )

# Scientific Integrity Callout with Validated Results
b_res = VALIDATED_FLUVIUS_RESULTS["baseline"]
g_res = VALIDATED_FLUVIUS_RESULTS["ga"]

st.markdown(
    f"""
    <div class="viva-box">
        <div class="viva-box-title">⚖️ Scientific Integrity & Validated Fluvius 2024 Findings</div>
        <p>
            In our previously validated 240-consumer Fluvius experiment:
            <br>
            • <strong>Baseline PSF + SOM + ANN:</strong> MAE = <strong>{b_res['mae']:.4f}</strong>, RMSE = <strong>{b_res['rmse']:.4f}</strong>, MAPE = <strong>{b_res['mape']:.2f}%</strong>
            <br>
            • <strong>GA-Optimized Model:</strong> MAE = <strong>{g_res['mae']:.4f}</strong>, RMSE = <strong>{g_res['rmse']:.4f}</strong>, MAPE = <strong>{g_res['mape']:.2f}%</strong>
            (selected {g_res['selected_hidden_neurons']} hidden neurons, lr = {g_res['selected_learning_rate']:.7f}, validation RMSE = {g_res['val_rmse']:.4f})
            <br><br>
            <em>{VALIDATED_FLUVIUS_RESULTS['explanation']}</em>
            This honest empirical finding demonstrates scientific rigor during capstone evaluation.
        </p>
    </div>
    """,
    unsafe_allow_html=True
)

# Navigation Quick Links
st.markdown("### 🧭 Interactive Application Modules")
nav_col1, nav_col2, nav_col3 = st.columns(3)

with nav_col1:
    st.markdown("#### 📁 Data & Exploration")
    st.markdown(
        "- **Dataset Upload:** Ingest Fluvius Part 1 & Part 2 ZIP archives with chunked processing.\n"
        "- **Preprocessing:** Check DST handling (March 31 / October 27) and chronological partition.\n"
        "- **Data Exploration:** Inspect 96-reading profiles across 8 residential consumer categories."
    )

with nav_col2:
    st.markdown("#### ⚡ Models & Forecasting")
    st.markdown(
        "- **Methodology:** Complete theoretical guide for SOM, PSF, ANN, and GA.\n"
        "- **Forecasting:** Select consumer and date to generate 96-interval forecast curve.\n"
        "- **GA Optimization:** Inspect population chromosomes, mutation, and validation RMSE."
    )

with nav_col3:
    st.markdown("#### 📊 Evaluation & Execution")
    st.markdown(
        "- **Model Comparison:** Side-by-side metric tables (Baseline vs GA-Optimized).\n"
        "- **Results & Viva Guide:** Comprehensive evaluation metrics and breakdown.\n"
        "- **Model Training:** Retrain SOM or ANN models with real-time feedback."
    )
